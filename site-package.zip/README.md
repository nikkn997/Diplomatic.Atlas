## Language coverage

- Bundled source-linked archive: 18 headline-and-summary translations for Russian, French, Spanish, Arabic and Simplified Chinese. Translations are unofficial and do not replace the original linked reporting.
- Capital names: Unicode CLDR exemplar cities supplemented by conventional-city-name mappings; original English remains the fallback when translated forms do not differ.
- GitHub Actions: best-effort Argos Translate offline model pipeline, no mandatory paid API. New headlines may remain in clearly labelled English if a language model cannot be installed. No translation or photography availability is guaranteed before the first successful GitHub run.
- Automated RSS images, event pins and World Bank data remain source-dependent. News stories never automatically generate inferred multilateral relationships.

# Diplomatic Atlas v1.11 — photo-first news release candidate

An independent student project on international relations. This is a **static research interface**, not an official UN service, diplomatic intelligence product, or real-time news agency.

## What is new

- **Country Compare**: 177 country/territory profiles with locally generated, full-bleed **fabric-style flags**. The textile artwork is a *stylised illustration* made from existing flag icons (not a photograph). Two output sets are included: `assets/flag-fabric/` for large card backgrounds and `assets/flag-flat/` for crisp small flags. The left text gradient preserves legibility; no remote CDN needed for these visuals.
- **World Briefing**: photo cards first try the actual publisher image discovered via RSS/Open Graph. When a source does not provide a suitable photograph, the news section can display one of seven **different** CC BY 4.0 photographs of the **related international forum** (IMF/WB Bangkok 2026 or COP31), verified through the Wikimedia Commons MediaWiki API and credited. These are *not* claimed to depict the specific article/press briefing. GitHub Actions caches the photos in the hosted site. Other articles show a compact text-first card instead of endlessly repeating the same institutional picture. See `PHOTO_CREDITS.md`. The starting archive contains 18 dated, sourced items.
- **Scheduled updates**: the Python `scripts/update_news.py` refreshes eight RSS sources: UN News, BBC World, two UN Geneva feeds, WHO, WTO, IAEA and Council of the EU. It retains only brief titles/excerpts, dates, publisher links, and publisher-provided image URLs. It does not copy/rehost whole articles or publisher photographs. Separately, the build caches seven individually assigned, explicitly CC-licensed related-forum photos with attribution. Unavailable feeds preserve the previous published snapshot.
- **Source-verified automated map layer**: `scripts/update_events.py` converts only official UN headlines explicitly locating talks/meetings/conferences in a known city into map/globe **venue pins**, with the article URL and approximate coordinates. **No automated participant connections or diplomatic outcomes are inferred.** Curated entries remain separate; 24 curated cases are bundled.
- **Indicators**: World Bank WDI statistics refresh automatically when the API works; each displayed observation includes its reference year and source. Older offline figures are labelled as archival.
- **Country research, UN votes, simulator and research library**: preserved from v1.5. 24 source-linked UNGA voting summaries are not a complete database.
- **Mobile and Mac**: responsive layout, local search using `⌘K` on macOS and `Ctrl+K` elsewhere, and a web app manifest. Safari on physical Apple devices still requires a user-side check.

## Run locally

Unzip and open `index.html`. For service-worker behavior and local data fetches, serve the folder with `python -m http.server 8000` and visit `http://localhost:8000/index.html`. No account or paid API is needed to open the offline baseline. Publisher photographs and direct Commons fallback require internet; the deployed GitHub Pages build attempts to cache seven individually credited photographs of related forums.

## Publication

Use **`PUBLISH_ONE_FILE_RU.md`** for the already configured repository `nikkn997/Diplomatic.Atlas`: upload **`site-package.zip`** without unpacking. The GitHub workflow checks the RSS sources about every five minutes (GitHub may delay/skip a run), persists previous snapshots, checks official meeting location pins, and refreshes WDI about every six hours. This build is not yet confirmed as deployed online.

### Safety and evidence limits

- A news headline is not proof of venue, attendance or political alignment.
- Automatically created event pins require explicit city/meeting language in the **official headline**; their city coordinates are approximate and not independently verified. No country-pair relationships are fabricated.
- RSS/editorial images may be subject to publisher copyrights and their availability can change. Attribution and original links are retained; image ownership is not transferred by linking. For commercial reuse, review and obtain permissions.
- The feed collector preserves previous data when a remote source is unavailable, and the UI never labels an archival snapshot as a live stream.
- GitHub's scheduled workflow may run late or become disabled for inactivity; check `Actions` for operational health. No paid infrastructure is required for a public GitHub Pages repository subject to GitHub's plan and limits.

## Validation

```bash
npm run check
npm test
python -m unittest discover -s tests -p 'test_news_fetch.py' -v
python -m unittest discover -s tests -p 'test_indicators_fetch.py' -v
python -m unittest discover -s tests -p 'test_events_fetch.py' -v
python -m unittest discover -s tests -p 'test_story_photos.py' -v
```

Additional information: `SOURCES_AND_METHODOLOGY.md` and `RELEASE_CHECKLIST_RU.md`.

## Main public sources

- UN News RSS: https://news.un.org/feed/subscribe/en/news/all/rss.xml
- BBC World RSS: https://feeds.bbci.co.uk/news/world/rss.xml
- UN Geneva press-items RSS: https://www.ungeneva.org/news-media/press-items-list/rss.xml
- UN Geneva meeting summaries RSS: https://www.ungeneva.org/news-media/meeting-summaries-list/rss.xml
- World Bank WDI API: https://api.worldbank.org/v2/indicator/SP.POP.TOTL?format=json
- GitHub Pages: https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages
- Natural Earth terms: https://www.naturalearthdata.com/about/terms-of-use/
- Original Noto Emoji icon artwork license: https://github.com/googlefonts/noto-emoji


## Source expansion and automated venue updates

- Additional optional RSS publishers: **World Trade Organization** (official news RSS), **International Atomic Energy Agency** (official news RSS), and **Council of the European Union** (press releases RSS).
- Publisher URLs were found in publicly documented sources; network availability can only be confirmed by GitHub Actions after deployment.
- Automated map pins require that an official headline explicitly names a meeting/summit city in a finite verified city list. The pin is approximate, with a source link; no inferred participants, diplomatic agreement, or participant connections.
- The GitHub deployment workflow checks headlines around every five minutes when GitHub runs it, retains snapshots in the repository, updates WDI approximately every six hours and skips unnecessary site deployments when data has not changed.
- This is **scheduled polling, not live breaking-news streaming**. Some RSS publishers omit images, may restrict deep links, or may deliver updates later than the underlying event.

/* Keyboard-accessible navigation. Works with Command+K on macOS and Ctrl+K elsewhere. */
(function(){'use strict';
  let previousFocus=null,overlay=null;
  const copy={en:['Jump to','Search a country or module…','Press Esc to close','Country','Module'],ru:['Быстрый переход','Поиск страны или раздела…','Esc — закрыть','Страна','Раздел'],fr:['Accès rapide','Pays ou rubrique…','Échap pour fermer','Pays','Rubrique'],es:['Acceso rápido','Buscar país o sección…','Esc para cerrar','País','Sección'],ar:['انتقال سريع','ابحث عن بلد أو قسم…','Esc للإغلاق','الدولة','القسم'],zh:['快速导航','搜索国家或栏目…','Esc 关闭','国家','栏目']};
  const modules=[['#home','navHome'],['#atlas','navAtlas'],['#signals','navSignals'],['#news','navNews'],['#compare','navCompare'],['#votes','navVotes'],['#sim','navSim'],['#research','navResearch']];
  const lang=()=>document.documentElement.lang||'en';
  function close(){if(!overlay)return;overlay.remove();overlay=null;previousFocus?.focus?.()}
  function open(){if(overlay)return;previousFocus=document.activeElement;const l=lang(),local=copy[l]||copy.en;
    overlay=document.createElement('div');overlay.className='command-overlay';
    overlay.innerHTML='<div class="command-modal" role="dialog" aria-modal="true" aria-labelledby="cmd-title"><div class="command-modal-top"><strong id="cmd-title"></strong><button type="button" id="cmd-close" aria-label="Close">×</button></div><input id="command-query" type="search" autocomplete="off" aria-label="Search"><div class="command-results" id="command-results"></div><div class="command-help"></div></div>';
    document.body.append(overlay);overlay.querySelector('#cmd-title').textContent=local[0];overlay.querySelector('#command-query').placeholder=local[1];overlay.querySelector('.command-help').textContent=local[2];overlay.querySelector('#cmd-close').addEventListener('click',close);overlay.addEventListener('pointerdown',e=>{if(e.target===overlay)close()});
    const input=overlay.querySelector('#command-query');input.addEventListener('input',show);input.addEventListener('keydown',e=>{if(e.key==='Enter'){overlay.querySelector('.command-result')?.click();e.preventDefault()}});input.focus();show();}
  function show(){if(!overlay)return;const q=overlay.querySelector('#command-query').value.trim().toLocaleLowerCase(),l=lang(),local=copy[l]||copy.en,panel=overlay.querySelector('#command-results');panel.replaceChildren();
    const labels=window.ATLAS_I18N?.[l]||window.ATLAS_I18N?.en||{};
    const results=modules.map(([href,key])=>({href,label:labels[key]||key,kind:local[4]})).filter(x=>!q||x.label.toLocaleLowerCase().includes(q));
    const countries=(window.ATLAS_COUNTRIES||[]).filter(c=>!q||[c.code,c.name,...Object.values(c.names||{})].join(' ').toLocaleLowerCase().includes(q)).slice(0,q?12:4).map(c=>({href:'#atlas/'+encodeURIComponent(c.code),label:c.names?.[l]||c.name,kind:local[3]}));
    [...results,...countries].slice(0,18).forEach(r=>{const btn=document.createElement('button');btn.type='button';btn.className='command-result';const name=document.createElement('strong');name.textContent=r.label;const kind=document.createElement('small');kind.textContent=r.kind;btn.append(name,kind);btn.addEventListener('click',()=>{close();location.hash=r.href});panel.append(btn)});
  }
  document.addEventListener('click',e=>{if(e.target.closest('[data-open-command]'))open()});
  document.addEventListener('keydown',e=>{if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='k'){e.preventDefault();overlay?close():open()}else if(e.key==='Escape'&&overlay){e.preventDefault();close()}});
})();

const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const root=path.resolve(__dirname,'..');
const photoManifest=JSON.parse(fs.readFileSync(path.join(root,'data/storyPhotoManifest.json'),'utf8'));
const archiveSrc=fs.readFileSync(path.join(root,'data/newsArchive.js'),'utf8');
const ctx={window:{}};vm.runInNewContext(archiveSrc,ctx);
const archive=new Set(ctx.window.ATLAS_NEWS_ARCHIVE.items.map(x=>x.url));
test('seven distinct verified contextual photos correspond to actual sourced headlines',()=>{
 assert.ok(photoManifest.photos.length>=7);
 const ids=new Set(),files=new Set();
 for(const p of photoManifest.photos){
  assert.ok(archive.has(p.storyUrl),p.storyUrl);
  assert.ok(!ids.has(p.id));ids.add(p.id);
  assert.ok(!files.has(p.fileTitle));files.add(p.fileTitle);
  assert.equal(p.license,'CC BY 4.0');
  assert.match(p.local,/^assets\/newsroom\/stories\/[-\w]+\.jpg$/);
  assert.match(p.page,/^https:\/\/commons\.wikimedia\.org\/wiki\/File:/);
 }
});
test('viewer uses dedicated distinct images; source photos never reuse institution fallback',()=>{
 const source=fs.readFileSync(path.join(root,'src/live.js'),'utf8');
 assert.match(source,/STORY_PHOTOS\[item\.url\]/);
 assert.match(source,/used\.has\(photo\.fileTitle\)/);
 assert.match(source,/article\.classList\.add\('photo-failed'\)/);
 assert.doesNotMatch(source,/const image=publisherPhoto\|\|ref\.local/);
});

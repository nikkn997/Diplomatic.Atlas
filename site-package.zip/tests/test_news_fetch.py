import datetime as dt
import tempfile
import unittest
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).parent.parent / 'scripts'))
import update_news

FIXED = dt.datetime(2026, 11, 23, 12, 0, tzinfo=dt.timezone.utc)

def rss(url, title):
    return f'''<?xml version="1.0"?><rss version="2.0"><channel><item><title>{title}</title><link>{url}</link><pubDate>Mon, 23 Nov 2026 09:30:00 GMT</pubDate></item></channel></rss>'''.encode()

class NewsTests(unittest.TestCase):
    def test_accepts_known_hosts_and_dated_entries(self):
        rows=update_news.parse_feed(rss('https://news.un.org/en/story/2026/11/000000','A verified UN news headline'), 'un', FIXED)
        self.assertEqual(len(rows),1)
        self.assertEqual(rows[0]['publisher'],'UN News')
        self.assertIsNone(update_news.safe_url('https://news.un.org.evil.example/a','un'))
        self.assertIsNone(update_news.safe_url('javascript:alert(1)','un'))
    def test_additional_institutional_publishers_enforce_domain_boundaries(self):
        for provider, url in (
            ('wto','https://www.wto.org/english/news_e/news_e.htm'),
            ('iaea','https://www.iaea.org/newscenter/news/example'),
            ('consilium','https://www.consilium.europa.eu/en/press/press-releases/example/'),
        ):
            self.assertIsNotNone(update_news.safe_url(url,provider))
            self.assertIsNone(update_news.safe_url('https://www.example.org/not-a-source',provider))

    def test_atom_feed_supports_dated_official_council_items(self):
        atom=("<feed xmlns='http://www.w3.org/2005/Atom'><entry>"
              "<title>Foreign affairs ministers meet in Brussels</title>"
              "<link rel='alternate' href='https://www.consilium.europa.eu/en/press/press-releases/meeting'/>"
              "<published>2026-11-23T10:20:00Z</published>"
              "<summary>Formal talks among ministers</summary>"
              "</entry></feed>").encode()
        rows=update_news.parse_feed(atom,'consilium',FIXED)
        self.assertEqual(len(rows),1)
        self.assertIn('Brussels',rows[0]['title'])
        self.assertEqual(rows[0]['source'],'consilium')

    def test_image_parser_ignores_logos_and_finds_article_image(self):
        parser=update_news.ArticleImageParser()
        parser.feed("<meta property='og:image' content='/images/company-logo.jpg'>"
                    "<meta name='twitter:image' content='https://cdn.who.int/media/images/event-photo.jpg'>")
        urls=[update_news.safe_media_url(__import__('urllib.parse').parse.urljoin('https://www.who.int/news/item/a', u))
              for u in parser.candidates]
        self.assertEqual(urls[0], '')
        self.assertEqual(urls[1], 'https://cdn.who.int/media/images/event-photo.jpg')

    def test_skips_dtd_and_untrusted_redirects(self):
        with self.assertRaises(ValueError):update_news.parse_feed(b'<!DOCTYPE rss [<!ENTITY x SYSTEM "file:///etc/passwd">]><rss/>','un',FIXED)
        self.assertFalse(update_news.parse_feed(rss('https://example.com/spoof','A made-up fake story'), 'bbc', FIXED))
    def test_update_pipeline_offline_fixtures(self):
        with tempfile.TemporaryDirectory() as folder:
            d=Path(folder);fixture=d/'fixtures';output=d/'out';fixture.mkdir()
            (fixture/'un.xml').write_bytes(rss('https://news.un.org/en/story/2026/11/000000','United Nations test headline only'))
            (fixture/'bbc.xml').write_bytes(rss('https://www.bbc.com/news/articles/12345','BBC World test headline only'))
            self.assertTrue(update_news.generate(fixture,output,now=FIXED))
            import json
            data=json.loads((output/'liveNews.json').read_text())
            self.assertEqual(len(data['items']),2)
            self.assertIn('BBC News', [x['publisher'] for x in data['items']])
            self.assertIn('window.ATLAS_LIVE_NEWS', (output/'liveNews.js').read_text())

if __name__=='__main__': unittest.main()

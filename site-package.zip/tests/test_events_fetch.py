import datetime as dt
import tempfile
import unittest
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'scripts'))
import update_events
NOW=dt.datetime(2026,11,24,12,tzinfo=dt.timezone.utc)

def item(title,url='https://www.ungeneva.org/en/news-media/press-release/2026/11/example'):
    return dict(title=title,url=url,published='2026-11-24T10:00:00Z',summary='A documented multilateral policy conversation at the venue.',publisher='UN Geneva')

class EventTests(unittest.TestCase):
    def test_extracts_explicit_meeting_venue_without_inventing_connections(self):
        e=update_events.event_from_story(item('International summit held in Geneva on public policy'))
        self.assertIsNotNone(e)
        self.assertEqual(e['city'],'Geneva')
        self.assertEqual(e['country'],'CHE')
        self.assertEqual(e['participants'],[])
        self.assertTrue(e['automated'])
        self.assertIn('headline',e['locationBasis'])
    def test_rejects_ambiguous_or_unsourced_events(self):
        self.assertIsNone(update_events.event_from_story(item('Geneva confronts complicated climate dilemma')))
        self.assertIsNone(update_events.event_from_story(item('Talks on Ukraine in Geneva',url='https://fake.example/test')))
        self.assertIsNone(update_events.event_from_story(item('Delegations negotiate climate policy without a specified venue')))
    def test_official_wto_iaea_council_venue_pins_without_invented_participants(self):
        fixtures=(
            ('WTO trade summit in Geneva','https://www.wto.org/english/news_e/news_e.htm','CHE'),
            ('IAEA conference in Vienna','https://www.iaea.org/newscenter/news/sample','AUT'),
            ('EU foreign affairs meeting in Brussels','https://www.consilium.europa.eu/en/press/press-releases/test','BEL'),
        )
        for title,url,country in fixtures:
            event=update_events.event_from_story(item(title,url))
            self.assertIsNotNone(event)
            self.assertEqual(event['country'],country)
            self.assertEqual(event['participants'],[])

    def test_does_not_count_capital_names_as_participants(self):
        e=update_events.event_from_story(item('Security meeting in Vienna on cooperation between France and Germany'))
        self.assertEqual(e['participants'],[])
    def test_auto_refresh_from_saved_official_news_snapshot(self):
        import json
        with tempfile.TemporaryDirectory() as path:
            root=Path(path)
            snap={'updated_at':NOW.isoformat(), 'sources':['un','consilium'], 'items':[
                {'source':'consilium','title':'Council summit in Brussels on regional security',
                 'published':'2026-11-24T09:30:00Z','publisher':'Council of the EU',
                 'url':'https://www.consilium.europa.eu/en/press/press-releases/meeting',
                 'summary':'Council ministers gathered to discuss security.'}
            ]}
            (root/'liveNews.json').write_text(json.dumps(snap),encoding='utf-8')
            self.assertTrue(update_events.generate(output_dir=root,now=NOW,from_news_snapshot=True))
            out=json.loads((root/'liveEvents.json').read_text(encoding='utf-8'))
            self.assertEqual(out['items'][0]['city'],'Brussels')
            self.assertEqual(out['items'][0]['participants'],[])
            self.assertIn('consilium',out['sources'])

    def test_output_files_from_offline_feeds(self):
        with tempfile.TemporaryDirectory() as path:
            root=Path(path);fi=root/'fixture';fi.mkdir()
            rss='''<rss version="2.0"><channel><item><title>Ministerial summit in Geneva on climate cooperation</title><link>https://www.ungeneva.org/en/news-media/press-release/test</link><pubDate>Tue, 24 Nov 2026 10:00:00 GMT</pubDate></item></channel></rss>'''
            for source in ('un','ungeneva','geneva_meetings'):
                (fi/(source+'.xml')).write_text(rss,encoding='utf-8')
            self.assertTrue(update_events.generate(fi,root/'out',now=NOW))
            import json
            d=json.loads((root/'out/liveEvents.json').read_text())
            self.assertEqual(len(d['items']),1)
            self.assertEqual(d['items'][0]['lat'],46.204)

if __name__=='__main__':unittest.main()

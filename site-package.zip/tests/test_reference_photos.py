import io
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import sys
sys.path.insert(0, str(Path(__file__).parent.parent / 'scripts'))
import fetch_reference_photos as photo


class DummyResponse:
    url = photo.PHOTOS['who']
    headers = {'Content-Type': 'image/jpeg'}
    def __enter__(self): return self
    def __exit__(self, *a): return None
    def read(self, count): return b'\xff\xd8\xff' + b'0' * 1100


class PhotoTests(unittest.TestCase):
    def test_photos_are_license_linked_trusted_sources(self):
        text = (photo.ROOT / 'PHOTO_CREDITS.md').read_text()
        for name, url in photo.PHOTOS.items():
            self.assertEqual(url.split('/')[2], 'upload.wikimedia.org')
            self.assertIn('commons.wikimedia.org', text)

    def test_download_writes_only_a_valid_jpeg_to_safe_destination(self):
        with tempfile.TemporaryDirectory() as tmp:
            with patch('fetch_reference_photos.urllib.request.urlopen', return_value=DummyResponse()):
                self.assertTrue(photo.retrieve('who', photo.PHOTOS['who'], Path(tmp)))
            self.assertTrue((Path(tmp) / 'who.jpg').read_bytes().startswith(b'\xff\xd8\xff'))

    def test_untrusted_urls_not_allowed(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(ValueError):
                photo.retrieve('who', 'https://evil.example/x.jpg', Path(tmp))

    def test_network_unavailable_fails_softly(self):
        with tempfile.TemporaryDirectory() as tmp:
            with patch('fetch_reference_photos.urllib.request.urlopen', side_effect=OSError('offline')):
                self.assertFalse(photo.retrieve('who', photo.PHOTOS['who'], Path(tmp)))


if __name__ == '__main__': unittest.main()

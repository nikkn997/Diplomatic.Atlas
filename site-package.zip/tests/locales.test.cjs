const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const root=path.resolve(__dirname,'..');
function data(file,name){const ctx=vm.createContext({window:{}});vm.runInContext(fs.readFileSync(path.join(root,'data',file),'utf8'),ctx);return ctx.window[name]}
test('all populated country capitals have Russian, Arabic and Chinese exonyms; other localizations are optional where name unchanged',()=>{
 const countries=data('countries.js','ATLAS_COUNTRIES');const capitals=data('capitals.js','ATLAS_CAPITALS');
 for(const c of countries){if(!c.capital)continue;assert.equal(capitals[c.code].en,c.capital,c.code);for(const lang of ['ru','ar','zh'])assert.ok(capitals[c.code][lang],`${c.code}:${lang}`)}
 assert.equal(capitals.CHN.ru,'Пекин');assert.equal(capitals.AUS.ru,'Канберра');assert.equal(capitals.DEU.ru,'Берлин');assert.equal(capitals.FRA.fr,'Paris');
});
test('18 bundled sourced headlines have titles and summaries in all five target languages',()=>{
 const archive=data('newsArchive.js','ATLAS_NEWS_ARCHIVE'),translated=data('newsTranslations.js','ATLAS_NEWS_TRANSLATIONS');
 assert.equal(archive.items.length,18);
 for(const a of archive.items){const translations=translated[a.url];assert.ok(translations,a.title);for(const l of ['ru','fr','es','ar','zh']){assert.ok(translations[l].title.length>9,l);assert.ok(translations[l].summary.length>12,l);}}
});
test('live news UI escapes translated text and honors country capital locales',()=>{
 const source=fs.readFileSync(path.join(root,'src/live.js'),'utf8');const app=fs.readFileSync(path.join(root,'src/app.js'),'utf8');
 assert.match(source,/esc\(copy\.title\)/);assert.match(source,/window\.ATLAS_NEWS_TRANSLATIONS/);
 assert.match(app,/capitalName\(c\)/);assert.match(app,/window\.ATLAS_CAPITALS/);
});

const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const file=f=>fs.readFileSync(path.join(root,f),'utf8');
function makeRenderer(options={}){
 const win={};
 const context=vm.createContext({window:win, URL, Date, localStorage:{getItem:()=>null},location:{protocol:'file:',hostname:'',hash:'#news'}});
 for(const script of ['data/countries.js','data/newsArchive.js','data/storyPhotos.js','data/newsTranslations.js'])vm.runInContext(file(script),context);
 win.ATLAS_LIVE_NEWS={items:[],updated_at:'2026-11-24T00:00:00Z'};
 if(options.publisher){
   win.ATLAS_LIVE_NEWS.items=[{source:'who',publisher:'WHO',title:'New regional health summit in Geneva',published:'2026-11-24T08:00:00Z',url:'https://www.who.int/news/item/example',image:'https://cdn.who.int/media/images/event-photo.jpg',category:'health'}]
 }
 vm.runInContext(file('src/live.js'),context);
 return win.AtlasLive;
}
test('related-forum photos are visibly qualified, source credited and not duplicated',()=>{
 const html=makeRenderer().render({state:{lang:'ru'}});
 assert.match(html,/class="newsroom-photo"/);
 assert.match(html,/assets\/newsroom\/stories\/un-cop31.jpg/);
 assert.match(html,/НЕ с этого конкретного события/);
 assert.match(html,/creativecommons.org|CC BY 4.0/);
 assert.match(html,/atlasNewsImageError/);
 const cards=html.match(/assets\/newsroom\/stories\/[-\w]+\.jpg(?=")/g)||[];
 assert.equal(new Set(cards).size,cards.length);
});
test('publisher-specific image takes priority over contextual photo',()=>{
 const html=makeRenderer({publisher:true}).render({state:{lang:'en'}});
 assert.match(html,/https:\/\/cdn.who.int\/media\/images\/event-photo.jpg/);
 assert.match(html,/Photograph supplied by publisher/);
 assert.match(html,/has-photo/);
});
test('failed source image tries a unique Commons file then downgrades to editorial card',()=>{
 makeRenderer();
 const source=file('src/live.js');
 assert.match(source,/img\.dataset\.fallbackStage='1'/);
 assert.match(source,/img\.dataset\.fallbackStage='2'/);
 assert.match(source,/article\.classList\.add\('photo-failed'\)/);
 assert.match(file('scripts/build_story_photos.py'),/commons\.wikimedia\.org/);
});

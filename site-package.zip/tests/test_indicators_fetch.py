import datetime as dt
import json
import tempfile
import unittest
from pathlib import Path
from importlib.util import module_from_spec, spec_from_file_location

ROOT = Path(__file__).resolve().parent.parent
spec = spec_from_file_location("indicators", ROOT / "scripts/update_indicators.py")
module = module_from_spec(spec)
spec.loader.exec_module(module)
UTC = dt.timezone.utc


class IndicatorsTests(unittest.TestCase):
    def setUp(self):
        self.today = dt.datetime(2026, 11, 23, tzinfo=UTC)
        self.tmp = tempfile.TemporaryDirectory()
        self.folder = Path(self.tmp.name)
        self.fixtures = self.folder / "fixtures"
        self.fixtures.mkdir()

    def tearDown(self):
        self.tmp.cleanup()

    def fixture(self, metric, identifier, value, year="2025"):
        observations = [
            {"countryiso3code": "FRA", "date": year, "value": value, "indicator": {"id": identifier}, "country": {"id": "FR"}},
            {"countryiso3code": "DEU", "date": year, "value": value * 2, "indicator": {"id": identifier}},
            {"countryiso3code": "XYZ", "date": year, "value": 999999, "indicator": {"id": identifier}},
        ]
        (self.fixtures / f"{metric}.json").write_text(json.dumps([{"pages": 1}, observations]), encoding="utf-8")

    def test_first_refresh_has_values_year_and_source(self):
        for metric, indicator in module.INDICATORS.items():
            self.fixture(metric, indicator, 65000000 if metric == "population" else 1000000)
        self.assertTrue(module.generate(self.fixtures, self.folder / "out", self.today))
        result = json.loads((self.folder / "out/indicators.json").read_text())
        self.assertEqual(result["source"], module.SOURCE)
        self.assertEqual(result["countries"]["FRA"]["population"]["year"], "2025")
        self.assertEqual(result["status"], "success")
        self.assertNotIn("XYZ", result["countries"])
        self.assertIn("window.ATLAS_INDICATORS", (self.folder / "out/indicators.js").read_text())

    def test_rejects_wrong_indicator_and_future_year(self):
        wrong = self.fixture("population", "WRONG.ID", 65000000)
        body = (self.fixtures / "population.json").read_bytes()
        self.assertEqual(module.parse_api(body, "SP.POP.TOTL", {"FRA", "DEU"}, self.today.date()), {})
        self.fixture("population", "SP.POP.TOTL", 65000000, "2040")
        body = (self.fixtures / "population.json").read_bytes()
        self.assertEqual(module.parse_api(body, "SP.POP.TOTL", {"FRA", "DEU"}, self.today.date()), {})

    def test_failure_preserves_existing_snapshot(self):
        output = self.folder / "out"
        output.mkdir()
        old = {"updated_at": "2026-01-01T00:00:00Z", "countries": {"FRA": {"population": {"value": 65000000, "year": "2024"}}}}
        (output / "indicators.json").write_text(json.dumps(old))
        self.assertFalse(module.generate(self.fixtures, output, self.today))
        self.assertEqual(json.loads((output / "indicators.json").read_text()), old)


if __name__ == "__main__":
    unittest.main()

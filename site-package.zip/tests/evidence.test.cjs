const assert=require('node:assert/strict'),{test}=require('node:test');
const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const root=path.resolve(__dirname,'..');
const ctx=vm.createContext({window:{}});
for(const p of ['data/events.js','data/votes.js','data/strings.js','data/earthTexture.js','data/countries.js'])vm.runInContext(fs.readFileSync(path.join(root,p),'utf8'),ctx,{filename:p});
const {ATLAS_EVENTS:events,ATLAS_VOTES:votes,ATLAS_I18N:languages,ATLAS_EARTH_TEXTURE:texture,ATLAS_COUNTRIES:countries}=ctx.window;
const codes=new Set(countries.map(x=>x.code));
const locales=['en','ru','fr','es','ar','zh'];
test('curated sourced geographic events keep known country references and dated records',()=>{
 assert.ok(events.length>=20);assert.equal(new Set(events.map(e=>e.id)).size,events.length);
 for(const e of events){
  assert.match(e.date,/^\d{4}-\d\d-\d\d$/);assert.ok(e.date<='2026-11-24',e.id);
  assert.match(e.source,/^https:\/\//);assert.ok(e.source.startsWith('https://www.un.org/')||e.source.includes('unfccc.int')||e.source.includes('mofa.gov.ae')||e.source.includes('un.org/')||e.source.includes('cbd.int')||e.source.includes('unep.org')||e.source.includes('digitallibrary.un.org')||e.source.includes('who.int')||e.source.includes('worldbank.org')||e.source.includes('mediacenter.imf.org')||e.source.includes('ungeneva.org'),e.id);
  assert.ok(e.lat>=-90&&e.lat<=90&&e.lon>=-180&&e.lon<=180,e.id);
  assert.ok(codes.has(e.country),`venue country ${e.country}`);
  for(const p of e.participants){assert.ok(codes.has(p.code),p.code);assert.ok(Number.isFinite(p.lat)&&Number.isFinite(p.lon))}
  assert.ok(e.title.en?.length>4,`${e.id} title en`);assert.ok(e.description.en?.length>20,`${e.id} desc en`);
 }
 const abu=events.find(e=>e.id==='abu26');assert.equal(abu.date,'2026-11-10');assert.deepEqual(Array.from(abu.participants.map(x=>x.code)).sort(),['RUS','UKR','USA']);
});
test('24 individually sourced General Assembly records with verified aggregate vote counts',()=>{
 assert.equal(votes.length,24);assert.equal(new Set(votes.map(v=>v.symbol)).size,24);
 for(const v of votes){assert.match(v.symbol,/^A\/RES\/(?:ES-\d+\/\d+|\d+\/\d+(?: [AB])?)$/);assert.ok(v.source.startsWith('https://digitallibrary.un.org/record/')||v.source.startsWith('https://www.un.org/unispal/'),v.source);assert.match(v.date,/^\d{4}-\d\d-\d\d$/);assert.ok(v.date<='2026-11-24');
 for(const col of ['yes','no','abstain'])assert.ok(Number.isInteger(v[col])&&v[col]>=0);
 assert.ok(v.yes+v.no+v.abstain<=193,v.symbol);assert.ok(!('countries' in v),'no uncited individual state voting');
 for(const lang of locales)assert.ok(v.title[lang]?.length>=4,`${lang} ${v.symbol}`);
 }
 const v= votes.find(x=>x.symbol==='A/RES/ES-10/21'); assert.equal(v.yes,120);assert.equal(v.no,14);assert.equal(v.abstain,45);
 const palestine=votes.find(x=>x.symbol==='A/RES/ES-10/23');assert.equal(palestine.source,'https://digitallibrary.un.org/record/4048289');
 const digital=votes.find(x=>x.symbol==='A/RES/80/215');assert.deepEqual([digital.yes,digital.no,digital.abstain],[174,3,4]);
 const child=votes.find(x=>x.symbol==='A/RES/80/190');assert.deepEqual([child.yes,child.no,child.abstain],[176,4,1]);
 const palestine2025=votes.find(x=>x.symbol==='A/RES/80/72');assert.deepEqual([palestine2025.yes,palestine2025.no,palestine2025.abstain],[151,11,11]);
});
test('WebGL texture is bundled inline to work without file fetch',()=>{
 assert.ok(texture.startsWith('data:image/webp;base64,'));assert.ok(texture.length>10000);
});
test('all translations include dynamic simulation branching copy',()=>{
 const keys=['extraChoices','adaptiveChoices','consequenceLow','consequenceMid','consequenceHigh','navSignals'];
 for(const lang of locales)for(const key of keys)assert.ok(languages[lang][key]?.length>=2,`${lang}.${key}`);
});

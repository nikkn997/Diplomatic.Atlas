const {test}=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const path=require('node:path');const vm=require('node:vm');
const root=path.resolve(__dirname,'..'),read=p=>fs.readFileSync(path.join(root,p),'utf8');
test('every country has local full-bleed cloth backdrop and flat flag badge',()=>{
 const context=vm.createContext({window:{}});vm.runInContext(read('data/countries.js'),context);
 const all=context.window.ATLAS_COUNTRIES;assert.equal(all.length,177);
 for(const c of all){for(const prefix of ['flag-fabric','flag-flat']){
  const p=path.join(root,'assets',prefix,c.code+'.webp');assert.ok(fs.existsSync(p),p);assert.ok(fs.statSync(p).size>100,p);
 }}
 assert.match(read('src/styles.css'),/display:block!important; content:""; position:absolute/);
 assert.match(read('src/app.js'),/assets\/flag-fabric/);
});
test('news uses publisher-supplied photos and does not disguise country flags as event photos',()=>{
 const ui=read('src/live.js'),pipeline=read('scripts/update_news.py');
 assert.match(ui,/class="newsroom-photo"/);assert.match(ui,/atlasNewsImageError/);assert.match(ui,/STORY_PHOTOS/);assert.match(ui,/captionsRelated/);
 assert.match(ui,/item\.image/);assert.match(pipeline,/media_thumbnail/);
 assert.doesNotMatch(ui,/flagImagePath\(item\.flagCode\)/);
});
test('scheduled workflow refreshes world briefing, mapping and indicators together',()=>{
 const wf=read('.github/workflows/update-headlines.yml');
 for(const script of ['update_news.py','update_indicators.py','update_events.py'])assert.ok(wf.includes(script));
 assert.ok(read('index.html').includes('data/liveEvents.js'));
});

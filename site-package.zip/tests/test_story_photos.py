import json
import pathlib
import sys
import tempfile
import unittest
from unittest import mock
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent / 'scripts'))
import build_story_photos as media

ROOT=pathlib.Path(__file__).parent.parent

class StoryPhotoTests(unittest.TestCase):
    def test_manifest_has_unique_photographs_and_exact_story_links(self):
        photos=json.loads((ROOT/'data/storyPhotoManifest.json').read_text(encoding='utf8'))['photos']
        assert len(photos)>=7
        self.assertEqual(len(set(p['storyUrl'] for p in photos)),len(photos))
        self.assertEqual(len(set(p['fileTitle'] for p in photos)),len(photos))
        self.assertEqual(len(set(p['local'] for p in photos)),len(photos))
        for p in photos:
            self.assertTrue(p['storyUrl'].startswith('https://'))
            self.assertEqual(p['license'],'CC BY 4.0')
            self.assertIn('not',p['caption']['en'].lower())
            self.assertTrue(p['page'].startswith('https://commons.wikimedia.org/wiki/File:'))
            self.assertIn('assets/newsroom/stories/',p['local'])

    def test_api_license_accepts_audited_cc_and_rejects_other(self):
        photo={'url':'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a1/cat.jpg/1100px-cat.jpg',
               'mime':'image/jpeg','extmetadata':{'LicenseUrl':{'value':'https://creativecommons.org/licenses/by/4.0/'},
                                                  'LicenseShortName':{'value':'CC BY 4.0'}}}
        response=json.dumps({'query':{'pages':[{'title':'File:Test.jpg','imageinfo':[photo]}]}}).encode()
        with mock.patch.object(media,'request',side_effect=lambda *args: (json.dumps({'query':{'pages':[{'title':'File:Test.jpg','imageinfo':[photo]}]}}).encode(), 'https://commons.wikimedia.org/w/api.php')):
            output=media.get_photo_info('File:Test.jpg')
            self.assertEqual(output['mime'],'image/jpeg')
            self.assertEqual(output['license'],'CC BY 4.0')
            self.assertIn('upload.wikimedia.org',output['url'])
            photo['extmetadata']['LicenseUrl']['value']='https://creativecommons.org/licenses/by-nc/4.0/'
            with self.assertRaises(ValueError):media.get_photo_info('File:Test.jpg')

    def test_rejects_untrusted_image_hosts(self):
        self.assertFalse(media.https_wikimedia('https://upload.wikimedia.org.evil.tld/bad.jpg','upload.wikimedia.org'))
        self.assertFalse(media.https_wikimedia('http://upload.wikimedia.org/bad.jpg','upload.wikimedia.org'))
        self.assertFalse(media.https_wikimedia('https://evil.com@upload.wikimedia.org/a.jpg','upload.wikimedia.org'))

    def test_cache_one_validates_bytes_and_prevents_unsafe_path(self):
        photo={'id':'test','fileTitle':'File:Test.jpg','local':'assets/newsroom/stories/test.jpg'}
        good=b'\xff\xd8\xff'+b'x'*4000
        with tempfile.TemporaryDirectory() as temp:
            with mock.patch.object(media,'get_photo_info',return_value={'url':'https://upload.wikimedia.org/x/test.jpg'}):
                with mock.patch.object(media,'request',return_value=(good,'https://upload.wikimedia.org/x/test.jpg')):
                    self.assertTrue(media.cache_one(photo,pathlib.Path(temp)))
                    self.assertEqual((pathlib.Path(temp)/photo['local']).read_bytes(),good)
        photo['local']='../../outside.jpg'
        with self.assertRaises(ValueError):media.cache_one(photo)

if __name__=='__main__':unittest.main()

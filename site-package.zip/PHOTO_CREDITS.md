# Reference photographs in World Briefing

Only photos of a documented related forum are used as licensed context for
specific articles; publisher-supplied photos of the actual reported event take
priority. The previous v1.10 fallback (reusing the same headquarters photograph
for every report from one institution) has been disabled. If neither is available,
the article is shown as a text-first card rather than an unlabelled photo.

Original full articles are not redistributed. Rights for publisher-generated images
must be assessed separately; the ability to embed a URL is not a license to
republish or cache the underlying photograph.

## v1.11: individual contextual photographs — licensed CC BY 4.0

Seven *different* photography assignments are listed in [`data/storyPhotoManifest.json`](data/storyPhotoManifest.json). Their [Wikimedia Commons](https://commons.wikimedia.org/) file pages provide the author, licensing terms and original event/date. The release checks `LicenseUrl` from the MediaWiki API before caching each JPEG. The photographs are credited in the news card. Distinct photos are used for separate articles, and related-event images are marked **not the specific briefing/news event**.

- IMF/WB Annual Meetings, Bangkok, 14–16 October 2026: five photographic works by Alisa Suwanrumpha / © European Union, 2026, [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). See the five individually linked Commons file pages in the manifest. These photographs show **different activities during the annual meetings**; none is described as a photograph of the specific IMF departmental press briefing.
- COP31, Antalya, November 2026: *ADB joins the Türkiye Industrial Decarbonization Investment Platform*, Eric Norman Sales / Asian Development Bank, [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/), and *President Masato Kanda Speaks on Behalf of Multilateral Development Bank Leaders at COP31*, source Asian Development Bank / Masato Kanda, [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). These depict related conference sessions, not the article's specific announcement or final plenary.

The related-forum cache is populated at site deployment; offline ZIP previews may load remote Commons fallbacks or show a text-only card if those are unavailable. Not every news article has a suitable freely licensed image, so coverage is necessarily partial.

#!/usr/bin/env python3
"""Curated, unofficial translations for the bundled 18-source headline archive.
The linked publisher headline is the authoritative original.
"""
from pathlib import Path
import json
root=Path(__file__).resolve().parent.parent
source=(root/'data/newsArchive.js').read_text(encoding='utf-8')
archive=json.loads(source[source.index('{'):].rstrip(' ;\n'))['items']
# Position follows source archive frozen as of 24 November 2026.
# Two values per row: translated title, faithfully paraphrased short summary.
ru=[
 ('COP31 завершилась без климатического соглашения; глава ООН подчеркнул однозначность научных данных','По сообщению ООН, переговоры по ископаемому топливу и финансированию на COP31 в Анталье завершились без общего климатического соглашения.'),
 ('Правительства объявили о более чем 230 новых обязательствах по предотвращению насилия в отношении детей','ВОЗ сообщила о более чем 230 обязательствах правительств перед глобальной конференцией по борьбе с насилием в отношении детей в Маниле.'),
 ('Государства подтвердили намерение завершить приложение PABS к соглашению о пандемиях к маю 2027 года','Государства вновь подтвердили график подготовки приложения о доступе к патогенам и распределении выгод к соглашению ВОЗ о пандемиях.'),
 ('Группа Всемирного банка поставила создание рабочих мест в центр климатических инвестиций на COP31','На COP31 в Анталье группа Всемирного банка представила инициативы по климатическому финансированию и созданию рабочих мест.'),
 ('Группа Всемирного банка изучает регулируемые стейблкоины для модернизации платежей','Группа Всемирного банка сообщила, что изучит инфраструктуру регулируемых стейблкоинов для платежей, связанных с развитием.'),
 ('Больше качественных рабочих мест — ключ к возобновлению сокращения бедности','Анализ Всемирного банка выделяет создание рабочих мест как важнейшее условие устойчивого сокращения бедности.'),
 ('ВОЗ выпустила рекомендации по предупреждению заболеваний от жары на массовых мероприятиях','ВОЗ представила научно обоснованные рекомендации по профилактике и лечению связанных с жарой заболеваний на фоне усиления тепловых рисков.'),
 ('ВОЗ представила последние мировые данные по холере, менингиту и чуме','ВОЗ обновила глобальную оценку ситуации с холерой, менингитом и чумой, отметив необходимость эпиднадзора и ответных мер.'),
 ('Мировые лидеры подтвердили обязательства по защите от будущих пандемий','По сообщению ВОЗ, государства вновь подтвердили обязательства по готовности к пандемиям в ходе недели Генассамблеи ООН.'),
 ('ВОЗ расширила рекомендации по безопасным методам контрацепции','ВОЗ объявила об обновлённых научно обоснованных рекомендациях по контрацепции и репродуктивному здоровью.'),
 ('ЮНЕП и ГЭФ начали глобальную инициативу по мониторингу токсичных веществ и ртути','ЮНЕП и Глобальный экологический фонд запустили инициативу по мониторингу химических веществ для поддержки международных соглашений и научно обоснованной политики.'),
 ('Всемирный день окружающей среды — 2026 призывает к срочным действиям по климату','ЮНЕП отметила Всемирный день окружающей среды призывом к климатическим действиям в условиях жары и усиления влияния Эль-Ниньо.'),
 ('Группа Всемирного банка представила первую цифровую стратегию для расширения доступа и создания рабочих мест','В Сеуле группа Всемирного банка объявила первую цифровую стратегию, направленную на цифровой доступ, услуги, навыки и занятость.'),
 ('Пресс-брифинг Международного валютно-финансового комитета МВФ','На ежегодной встрече МВФ в Бангкоке руководство обсудило рост, долговые риски, конфликты и экономические последствия ИИ.'),
 ('Пресс-брифинг МВФ по Западному полушарию','На брифинге в Бангкоке представители МВФ рассмотрели рост, инфляцию, торговлю, инвестиции и долговые риски региона.'),
 ('Пресс-брифинг МВФ по докладу «Бюджетный монитор»','Департамент бюджетных вопросов МВФ рассказал в Бангкоке о фискальных рисках, энергетических шоках и налоговых реформах.'),
 ('Пресс-брифинг МВФ по Ближнему Востоку и Центральной Азии','МВФ представил в Бангкоке оценку роста, инфляции и уязвимостей стран Ближнего Востока и Центральной Азии.'),
 ('Пресс-брифинг МВФ по Азиатско-Тихоокеанскому региону','Департамент МВФ по Азии и Тихому океану рассказал в Бангкоке об устойчивости региона, технологическом росте и экономических приоритетах.'),
]
fr=[
 ('La COP31 se termine sans pacte climatique, tandis que le chef de l’ONU souligne la clarté des données scientifiques','Selon l’ONU, les discussions sur les combustibles fossiles et le financement à Antalya n’ont pas abouti à un accord climatique global.'),
 ('Les gouvernements prennent plus de 230 nouveaux engagements contre les violences envers les enfants','L’OMS a annoncé plus de 230 engagements gouvernementaux avant la conférence mondiale sur la fin des violences envers les enfants à Manille.'),
 ('Les États réaffirment leur volonté de finaliser l’annexe PABS de l’accord sur les pandémies d’ici mai 2027','Les États ont confirmé le calendrier de l’annexe sur l’accès aux agents pathogènes et le partage des avantages de l’accord de l’OMS.'),
 ('Le Groupe de la Banque mondiale place l’emploi au cœur des investissements climatiques de la COP31','À Antalya, le Groupe de la Banque mondiale a présenté des projets de financement climatique et de création d’emplois.'),
 ('La Banque mondiale étudie les stablecoins réglementés pour moderniser les paiements','Le Groupe de la Banque mondiale examine l’utilisation de stablecoins réglementés pour des paiements liés au développement.'),
 ('Des emplois plus nombreux et de meilleure qualité sont essentiels pour réduire la pauvreté','Une analyse de la Banque mondiale souligne le rôle de la création d’emplois dans la réduction durable de la pauvreté.'),
 ('L’OMS publie de nouvelles recommandations contre les maladies liées à la chaleur lors de grands rassemblements','L’OMS propose des mesures fondées sur des données scientifiques pour prévenir les maladies liées à la chaleur pendant les grands événements.'),
 ('L’OMS publie les dernières tendances mondiales du choléra, de la méningite et de la peste','L’OMS actualise la situation mondiale et souligne les besoins de surveillance et de réponse sanitaire.'),
 ('Les dirigeants mondiaux renouvellent leurs engagements contre les futures pandémies','Selon l’OMS, les États ont réaffirmé leurs engagements en matière de préparation aux pandémies durant l’Assemblée générale des Nations unies.'),
 ('L’OMS élargit les options sûres en matière de contraception','L’OMS a annoncé de nouvelles recommandations fondées sur des données scientifiques sur la contraception et la santé reproductive.'),
 ('Le PNUE et le FEM lancent une initiative mondiale de suivi des substances toxiques et du mercure','Le PNUE et le Fonds pour l’environnement mondial lancent une initiative de surveillance des produits chimiques pour appuyer les traités et les politiques publiques.'),
 ('Face au réchauffement, la Journée mondiale de l’environnement 2026 appelle à agir d’urgence','Le PNUE réclame une action climatique rapide face aux fortes chaleurs et aux pressions liées à El Niño.'),
 ('La Banque mondiale lance sa première stratégie numérique pour élargir l’accès et créer des emplois','À Séoul, le Groupe de la Banque mondiale a présenté une stratégie pour l’accès numérique, les services, les compétences et l’emploi.'),
 ('Conférence de presse du Comité monétaire et financier international du FMI','Lors des réunions annuelles à Bangkok, le FMI a abordé la croissance, la dette, les conflits et les risques économiques liés à l’IA.'),
 ('Conférence de presse du FMI sur l’hémisphère occidental','À Bangkok, le FMI a analysé la croissance, l’inflation, le commerce, l’investissement et la dette dans la région.'),
 ('Conférence de presse du FMI sur le Moniteur des finances publiques','Le FMI a présenté les risques budgétaires, les chocs énergétiques et les priorités de réforme fiscale à Bangkok.'),
 ('Conférence de presse du FMI sur le Moyen-Orient et l’Asie centrale','Le FMI a évoqué à Bangkok la croissance, l’inflation et les vulnérabilités des économies du Moyen-Orient et d’Asie centrale.'),
 ('Conférence de presse du FMI sur l’Asie et le Pacifique','Le FMI a présenté à Bangkok la résilience régionale, la croissance technologique et les priorités économiques.'),
]
es=[
 ('La COP31 termina sin pacto climático y el jefe de la ONU destaca la claridad de la evidencia científica','Según la ONU, las conversaciones sobre combustibles fósiles y financiación en Antalya no lograron un acuerdo climático general.'),
 ('Los gobiernos anuncian más de 230 nuevos compromisos contra la violencia infantil','La OMS comunicó más de 230 compromisos gubernamentales antes de la conferencia mundial en Manila contra la violencia infantil.'),
 ('Los Estados reiteran su compromiso de finalizar el anexo PABS del acuerdo sobre pandemias en mayo de 2027','Los países confirmaron el calendario del anexo sobre acceso a patógenos y distribución de beneficios del acuerdo de la OMS.'),
 ('El Banco Mundial sitúa el empleo en el centro de las inversiones climáticas de la COP31','En Antalya, el Grupo Banco Mundial destacó proyectos de financiación climática y creación de empleo.'),
 ('El Banco Mundial estudia stablecoins reguladas para modernizar los pagos','El Grupo Banco Mundial anunció que explorará infraestructuras de stablecoins reguladas para pagos vinculados al desarrollo.'),
 ('Más y mejores empleos son esenciales para volver a reducir la pobreza','Un análisis del Banco Mundial destaca la creación de empleo como clave para una reducción sostenible de la pobreza.'),
 ('La OMS publica nuevas pautas para prevenir enfermedades por calor en eventos multitudinarios','La OMS ofreció recomendaciones basadas en pruebas para prevenir y atender enfermedades relacionadas con el calor.'),
 ('La OMS actualiza las tendencias mundiales del cólera, la meningitis y la peste','La OMS presentó información actualizada y destacó las necesidades de vigilancia y respuesta sanitaria.'),
 ('Los líderes mundiales renuevan sus compromisos frente a futuras pandemias','Según la OMS, los Estados renovaron sus compromisos de preparación durante la semana de la Asamblea General de la ONU.'),
 ('La OMS amplía las opciones seguras de anticoncepción','La OMS anunció recomendaciones basadas en pruebas sobre anticoncepción y salud reproductiva.'),
 ('El PNUMA y el FMAM lanzan una iniciativa mundial para vigilar sustancias tóxicas y mercurio','El PNUMA y el Fondo para el Medio Ambiente Mundial iniciaron un proyecto para mejorar el seguimiento de sustancias químicas.'),
 ('El Día Mundial del Medio Ambiente 2026 pide medidas climáticas urgentes ante el calor','El PNUMA pidió acelerar la acción climática frente a temperaturas extremas y presiones de El Niño.'),
 ('El Banco Mundial lanza su primera estrategia digital para ampliar el acceso y generar empleo','En Seúl, el Grupo Banco Mundial presentó una estrategia sobre acceso digital, servicios, competencias y empleo.'),
 ('Rueda de prensa del Comité Monetario y Financiero Internacional del FMI','Durante las reuniones en Bangkok, el FMI trató el crecimiento, la deuda, los conflictos y los riesgos de la IA.'),
 ('Rueda de prensa del FMI sobre el hemisferio occidental','En Bangkok, el FMI abordó el crecimiento regional, la inflación, el comercio, la inversión y la deuda.'),
 ('Rueda de prensa del FMI sobre el Monitor Fiscal','El FMI describió en Bangkok los riesgos presupuestarios, los impactos energéticos y las reformas fiscales.'),
 ('Rueda de prensa del FMI sobre Oriente Medio y Asia Central','En Bangkok, el FMI analizó el crecimiento, la inflación y las vulnerabilidades económicas de la región.'),
 ('Rueda de prensa del FMI sobre Asia y el Pacífico','El FMI abordó en Bangkok la resiliencia regional, el crecimiento tecnológico y las prioridades económicas.'),
]
ar=[
 ('اختتام مؤتمر COP31 دون اتفاق مناخي شامل والأمين العام للأمم المتحدة يؤكد وضوح الأدلة العلمية','أفادت الأمم المتحدة بأن مفاوضات الوقود الأحفوري والتمويل في أنطاليا انتهت دون اتفاق مناخي شامل.'),
 ('الحكومات تعلن أكثر من 230 تعهداً جديداً لمنع العنف ضد الأطفال','أعلنت منظمة الصحة العالمية أكثر من 230 التزاماً حكومياً قبل المؤتمر العالمي لإنهاء العنف ضد الأطفال في مانيلا.'),
 ('الدول تؤكد التزامها بإكمال ملحق PABS لاتفاق الجوائح بحلول مايو 2027','أكدت الدول الجدول الزمني لملحق إتاحة مسببات الأمراض وتقاسم المنافع ضمن اتفاق منظمة الصحة العالمية.'),
 ('مجموعة البنك الدولي تضع الوظائف في صلب الاستثمارات المناخية خلال COP31','سلطت مجموعة البنك الدولي في أنطاليا الضوء على مشروعات تمويل المناخ وخلق فرص العمل.'),
 ('مجموعة البنك الدولي تدرس العملات المستقرة الخاضعة للتنظيم لتحديث المدفوعات','أعلنت مجموعة البنك الدولي أنها ستدرس بنية العملات المستقرة المنظمة للمدفوعات المرتبطة بالتنمية.'),
 ('المزيد من الوظائف الجيدة مفتاح العودة إلى مسار الحد من الفقر','يشدد تحليل للبنك الدولي على أن خلق الوظائف ضروري للحد المستدام من الفقر.'),
 ('منظمة الصحة العالمية تصدر إرشادات للوقاية من الأمراض المرتبطة بالحر في التجمعات الكبرى','قدمت المنظمة توصيات مستندة إلى الأدلة للوقاية من أمراض الحر والتعامل معها في الفعاليات الكبرى.'),
 ('منظمة الصحة العالمية تعرض أحدث اتجاهات الكوليرا والتهاب السحايا والطاعون عالمياً','حدثت المنظمة تقييمها العالمي لهذه الأمراض وشددت على احتياجات الترصد والاستجابة.'),
 ('قادة العالم يجددون التزامهم بالحماية من الجوائح المستقبلية','وفقاً للمنظمة، جددت الدول التزاماتها بالاستعداد للجوائح خلال أسبوع الجمعية العامة للأمم المتحدة.'),
 ('منظمة الصحة العالمية توسع خيارات منع الحمل الآمنة','أعلنت المنظمة توصيات محدثة قائمة على الأدلة بشأن منع الحمل والصحة الإنجابية.'),
 ('برنامج الأمم المتحدة للبيئة ومرفق البيئة العالمية يطلقان مبادرة لرصد المواد السامة والزئبق','أطلق الطرفان مبادرة عالمية لرصد المواد الكيميائية ودعم تنفيذ المعاهدات والسياسات المبنية على الأدلة.'),
 ('اليوم العالمي للبيئة 2026 يدعو إلى تحرك مناخي عاجل مع اشتداد الحر','دعا البرنامج إلى عمل مناخي سريع في ظل ارتفاع درجات الحرارة وضغوط ظاهرة إل نينيو.'),
 ('مجموعة البنك الدولي تطلق أول استراتيجية رقمية لتوسيع الوصول وخلق الوظائف','أعلنت المجموعة في سيول استراتيجية رقمية تركز على الوصول إلى الخدمات والمهارات الرقمية وفرص العمل.'),
 ('إحاطة صحفية للجنة النقدية والمالية الدولية في صندوق النقد الدولي','ناقشت قيادة الصندوق في بانكوك النمو والديون والنزاعات والمخاطر الاقتصادية المرتبطة بالذكاء الاصطناعي.'),
 ('إحاطة صحفية لصندوق النقد الدولي بشأن نصف الكرة الغربي','تناولت الإحاطة في بانكوك النمو والتضخم والتجارة والاستثمار وضغوط الديون في المنطقة.'),
 ('إحاطة صحفية لصندوق النقد الدولي بشأن تقرير الراصد المالي','أوضح الصندوق في بانكوك المخاطر المالية وصدمات الطاقة وأولويات الإصلاح الضريبي.'),
 ('إحاطة صحفية لصندوق النقد الدولي بشأن الشرق الأوسط وآسيا الوسطى','ناقشت الإحاطة النمو والتضخم والهشاشة الاقتصادية في الشرق الأوسط وآسيا الوسطى.'),
 ('إحاطة صحفية لصندوق النقد الدولي بشأن آسيا والمحيط الهادئ','ناقش الصندوق في بانكوك مرونة المنطقة والنمو المدفوع بالتكنولوجيا والأولويات الاقتصادية.'),
]
zh=[
 ('COP31未达成总体气候协议，联合国秘书长强调科学证据明确','联合国表示，安塔利亚举行的COP31在化石燃料和资金问题上未能达成总体气候协议。'),
 ('各国政府作出230多项防止针对儿童暴力的新承诺','世界卫生组织称，在马尼拉召开结束针对儿童暴力的全球会议前，各国政府提出了230多项新承诺。'),
 ('成员国重申将在2027年5月前完成大流行协定PABS附件','各国重申了完成世卫组织大流行协定中病原体获取与惠益分享附件的时间表。'),
 ('世界银行集团将创造就业置于COP31气候投资核心','在安塔利亚COP31会议上，世界银行集团重点介绍了气候融资与就业项目。'),
 ('世界银行集团探索以受监管稳定币推动支付现代化','世界银行集团表示，将研究用于发展相关支付的受监管稳定币基础设施。'),
 ('更多更好的就业机会是重回减贫轨道的关键','世界银行分析强调，创造就业是实现可持续减贫的重要条件。'),
 ('世卫组织发布大型活动高温相关疾病预防新指南','世卫组织公布循证建议，帮助活动主办方预防和应对高温相关疾病。'),
 ('世卫组织发布霍乱、脑膜炎和鼠疫的最新全球趋势','世卫组织更新了相关疾病的全球情况，并强调监测与应对需求。'),
 ('世界领导人重申防范未来大流行的承诺','据世卫组织称，各国在联合国大会周期间重申了大流行防范承诺。'),
 ('世卫组织扩大安全避孕方案的建议范围','世卫组织公布了有关避孕和生殖健康的最新循证建议。'),
 ('联合国环境规划署与全球环境基金启动有毒化学品和汞监测倡议','双方启动了全球化学品监测倡议，以支持条约执行与循证政策。'),
 ('2026年世界环境日呼吁采取紧急气候行动','联合国环境规划署呼吁在高温和厄尔尼诺压力加剧之际加快气候行动。'),
 ('世界银行集团推出首个数字战略，以扩大服务覆盖并创造就业','世界银行集团在首尔发布数字战略，聚焦数字接入、服务、技能和就业。'),
 ('国际货币与金融委员会新闻发布会','在曼谷的国际货币基金组织年会上，管理层讨论了增长、债务、冲突及人工智能相关经济风险。'),
 ('国际货币基金组织西半球新闻发布会','基金组织在曼谷介绍了区域增长、通胀、贸易、投资和债务压力。'),
 ('国际货币基金组织《财政监测报告》新闻发布会','基金组织在曼谷介绍了财政风险、能源冲击和税制改革重点。'),
 ('国际货币基金组织中东和中亚新闻发布会','基金组织在曼谷分析了中东和中亚的增长、通胀及经济脆弱性。'),
 ('国际货币基金组织亚太地区新闻发布会','基金组织在曼谷讨论了区域韧性、技术驱动增长和经济政策重点。'),
]
d={'ru':ru,'fr':fr,'es':es,'ar':ar,'zh':zh}
assert all(len(d[lang])==len(archive) for lang in d)
output={}
for i,article in enumerate(archive):
 output[article['url']]={lang:{'title':d[lang][i][0],'summary':d[lang][i][1]} for lang in d}
(root/'data/newsTranslations.js').write_text('/* Unofficial editorial translations of the frozen source-linked archive. */\nwindow.ATLAS_NEWS_TRANSLATIONS='+json.dumps(output,ensure_ascii=False,separators=(',',':'))+';\n',encoding='utf-8')
print('localized headlines:',len(output),'languages',list(d))

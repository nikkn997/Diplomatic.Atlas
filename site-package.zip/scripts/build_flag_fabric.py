#!/usr/bin/env python3
"""Render local flag-cloth backgrounds from the supplied offline icons.

Input icons are cut-out waving stickers. Recover the original full rectangular
flag by sampling between top/bottom alpha edges for each column, then add soft
folds and a textile sheen. The generated images are *illustrations*, not photos.
"""
from pathlib import Path
from PIL import Image
import cv2
import numpy as np

ROOT=Path(__file__).resolve().parent.parent
SRC=ROOT/'assets/flags'
DST=ROOT/'assets/flag-fabric'
DST.mkdir(parents=True,exist_ok=True)
FLAT=ROOT/'assets/flag-flat'
FLAT.mkdir(parents=True,exist_ok=True)
W,H=1200,760
x=np.linspace(0,1,W,dtype=np.float32)[None,:]
y=np.linspace(0,1,H,dtype=np.float32)[:,None]
X=np.broadcast_to(x,(H,W))
Y=np.broadcast_to(y,(H,W))
phase=2*np.pi*(X*1.7+Y*.23)
phase2=2*np.pi*(X*3.55-Y*.25)
weave=.004*np.sin(X*W*np.pi/2.2)+.004*np.cos(Y*H*np.pi/2.2)
light=np.clip(.92+.16*np.cos(phase-.35)+.06*np.sin(phase2)+weave,.73,1.16)
light*=(1-.027*Y)

for source in sorted(SRC.glob('*.png')):
    try:
        rgba=np.asarray(Image.open(source).convert('RGBA'),dtype='uint8')
        a=rgba[:,:,3]
        ys,xs=np.where(a>60)
        if len(xs)<100:continue
        xmin,xmax=int(xs.min()),int(xs.max());crop=rgba[:,xmin:xmax+1]
        # Extract the colored cloth column to restore a full rectangular flag.
        valid=crop[:,:,3]>60
        top=np.argmax(valid,axis=0).astype('float32')
        bottom=(crop.shape[0]-1-np.argmax(valid[::-1,:],axis=0)).astype('float32')
        top=cv2.GaussianBlur(top[None,:],(1,1),0)[0]
        bottom=cv2.GaussianBlur(bottom[None,:],(1,1),0)[0]
        # Work in the exact original crop width; interpolation is acceptable for
        # illustration, but no details are created that were not in the source.
        xpos=(X*(crop.shape[1]-1)).astype('float32')
        fromtop=np.interp(xpos.ravel(),np.arange(crop.shape[1]),top).reshape(H,W)
        frombot=np.interp(xpos.ravel(),np.arange(crop.shape[1]),bottom).reshape(H,W)
        original_y=np.clip(Y+.013*np.sin(phase)+.007*np.sin(phase2),0,1)
        ypos=(fromtop+(frombot-fromtop)*original_y).astype('float32')
        # RGB only; transparent icon edges must not become black cloth.
        rgb=np.where(crop[:,:,3:4]<20,255,crop[:,:,:3])
        warped=cv2.remap(rgb,xpos,ypos,cv2.INTER_CUBIC,borderMode=cv2.BORDER_REPLICATE).astype('float32')
        out=np.clip(warped*light[...,None],0,255).astype('uint8')
        Image.fromarray(out).save(DST/(source.stem+'.webp'),format='WEBP',quality=88,method=5)
        plain_y=(fromtop+(frombot-fromtop)*Y).astype('float32')
        plain=cv2.remap(rgb,xpos,plain_y,cv2.INTER_CUBIC,borderMode=cv2.BORDER_REPLICATE)
        Image.fromarray(plain).resize((660,420),Image.Resampling.LANCZOS).save(FLAT/(source.stem+'.webp'),format='WEBP',quality=94,method=5)
    except Exception as e:
        print('SKIPPED',source.name,str(e))
print('Generated',len(list(DST.glob('*.webp'))),'rectangular fabric backdrops')

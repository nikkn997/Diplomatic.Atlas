from pathlib import Path
from playwright.sync_api import sync_playwright
import json,re
root=Path(__file__).resolve().parents[1]
html=(root/'index.html').read_text(encoding='utf-8')
html=re.sub(r'<link[^>]+href="https://[^>]+>','',html)
html=html.replace('<link rel="stylesheet" href="src/styles.css">','<style>'+(root/'src/styles.css').read_text(encoding='utf-8')+'</style>')
for match in list(re.finditer(r'<script src="([^"]+)"></script>',html)):
 src=match.group(1)
 html=html.replace(match.group(0),'<script>'+(root/src).read_text(encoding='utf-8')+'</script>')
report={'errors':[]}
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--enable-unsafe-swiftshader','--use-angle=swiftshader'])
 page=browser.new_page(viewport={'width':1440,'height':1050})
 page.on('pageerror',lambda e:report['errors'].append(str(e)))
 page.set_content(html,wait_until='domcontentloaded',timeout=30000)
 page.wait_for_timeout(300)
 page.evaluate('location.hash="#news"')
 page.wait_for_timeout(240)
 page.locator('#language').select_option('ru')
 page.wait_for_timeout(260)
 titles=page.locator('.newsroom-article h3').all_text_contents()
 report['ru_headline_0']=titles[0] if titles else 'MISSING'
 report['ru_news']=('научных данных' in titles[0].lower()) if titles else False
 page.screenshot(path='/mnt/data/atlas-v18-news-ru.png',full_page=False)
 page.evaluate('location.hash="#atlas/CHN"')
 page.wait_for_timeout(260)
 report['ru_beijing']='Пекин' in page.locator('body').inner_text()
 page.screenshot(path='/mnt/data/atlas-v18-china-ru.png',full_page=False)
 page.locator('#language').select_option('fr')
 page.wait_for_timeout(180)
 report['fr_beijing']='Pékin' in page.locator('body').inner_text()
 page.evaluate('location.hash="#news"')
 page.wait_for_timeout(260)
 report['fr_headline']=page.locator('.newsroom-article h3').first.inner_text()
 page.locator('#language').select_option('zh')
 page.wait_for_timeout(180)
 report['zh_headline']=page.locator('.newsroom-article h3').first.inner_text()
 page.evaluate('location.hash="#atlas/CHN"')
 page.wait_for_timeout(270)
 report['zh_beijing']='北京' in page.locator('body').inner_text()
 browser.close()
Path('/mnt/data/atlas-v18-browser-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))

#!/usr/bin/env python3
"""Refresh most recent nonempty WDI indicators into a static, attributed snapshot.

The build preserves the previous complete snapshot when all remote requests fail.
The source, indicator, data year and retrieval timestamp accompany every value.
The script uses only Python's stdlib. No keys, tracking or inferred current figures.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import math
import re
import sys
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
UTC = dt.timezone.utc
INDICATORS = {
    "population": "SP.POP.TOTL",
    "gdp": "NY.GDP.MKTP.CD",
    "gdpPerCapita": "NY.GDP.PCAP.CD",
}
SOURCE = "World Bank — World Development Indicators"
BASE = "https://api.worldbank.org/v2/country/all/indicator/"


def country_iso3_codes():
    text = (ROOT / "data/countries.js").read_text(encoding="utf-8")
    begin = text.index("[")
    end = text.rindex("]") + 1
    return {row["code"] for row in json.loads(text[begin:end]) if re.fullmatch(r"[A-Z]{3}", row["code"])}


def parse_api(payload: bytes, expected_indicator: str, valid_codes: set[str], today: dt.date):
    if len(payload) > 5_000_000:
        raise ValueError("Data response too large")
    content = json.loads(payload)
    if not isinstance(content, list) or len(content) != 2 or not isinstance(content[1], list):
        raise ValueError("World Bank API expected a two-item JSON list")
    results: dict[str, dict] = {}
    for item in content[1]:
        if not isinstance(item, dict):
            continue
        code = item.get("countryiso3code")
        indicator = item.get("indicator")
        year = str(item.get("date", ""))
        value = item.get("value")
        if code not in valid_codes or not isinstance(indicator, dict) or indicator.get("id") != expected_indicator:
            continue
        if not re.fullmatch(r"\d{4}", year) or not (1960 <= int(year) <= today.year):
            continue
        if not isinstance(value, (int, float)) or isinstance(value, bool) or not math.isfinite(value) or value < 0:
            continue
        if expected_indicator == "SP.POP.TOTL" and value < 100:
            continue
        if code not in results or int(year) > int(results[code]["year"]):
            results[code] = {"value": value, "year": year}
    return results


def fetch(indicator: str) -> bytes:
    url = f"{BASE}{indicator}?format=json&mrnev=1&per_page=2000"
    request = urllib.request.Request(url, headers={"User-Agent": "DiplomaticAtlas/1.1 (educational static data cache)", "Accept": "application/json"})
    with urllib.request.urlopen(request, timeout=20) as response:
        return response.read(5_000_001)


def write_snapshot(data: dict, folder: Path):
    folder.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    (folder / "indicators.json").write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (folder / "indicators.js").write_text("window.ATLAS_INDICATORS = " + payload.replace("<", "\\u003c") + ";\n", encoding="utf-8")


def generate(fixtures: Path | None = None, output: Path | None = None, now: dt.datetime | None = None) -> bool:
    now = now or dt.datetime.now(UTC)
    output = output or ROOT / "data"
    previous_path = output / "indicators.json"
    try:
        previous = json.loads(previous_path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        previous = {"updated_at": None, "source": SOURCE, "indicators": INDICATORS, "countries": {}}
    if not isinstance(previous.get("countries"), dict):
        previous["countries"] = {}
    valid_codes = country_iso3_codes()
    success = 0
    for key, indicator in INDICATORS.items():
        try:
            payload = (fixtures / f"{key}.json").read_bytes() if fixtures else fetch(indicator)
            rows = parse_api(payload, indicator, valid_codes, now.date())
            if not rows:
                raise ValueError("No valid country observations")
            for code, record in rows.items():
                previous["countries"].setdefault(code, {})[key] = record
            success += 1
            print(f"{key}: updated {len(rows)} observations")
        except Exception as exc:
            print(f"{key}: {exc}", file=sys.stderr)
    if success == 0:
        print("No indicators updated; cached snapshot was preserved", file=sys.stderr)
        return False
    previous.update({"updated_at": now.strftime("%Y-%m-%dT%H:%M:%SZ"), "source": SOURCE, "indicators": INDICATORS, "status": "success" if success == len(INDICATORS) else "partial"})
    write_snapshot(previous, output)
    return True


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--fixtures", type=Path)
    p.add_argument("--output", type=Path)
    a = p.parse_args()
    sys.exit(0 if generate(a.fixtures, a.output) else 1)

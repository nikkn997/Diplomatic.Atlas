#!/usr/bin/env python3
"""Generate local capital names from installed CLDR (Babel) plus checked city-name overrides.

Not a geopolitical status statement; English source city names remain preserved.
Run manually when upgrading the static country dataset. No network access required.
"""
import json
from pathlib import Path
from babel.core import Locale
ROOT=Path(__file__).resolve().parent.parent
raw=(ROOT/'data/countries.js').read_text(encoding='utf-8')
items=json.loads(raw[raw.index('['):raw.rindex(']')+1])
# For cities lacking a matching CLDR time-zone exemplar; localized conventional names.
# Fields: Russian, French, Spanish, Arabic, Chinese (simplified).
manual={
 'Suva': ['Сува','Suva','Suva','سوفا','苏瓦'],
 'Dodoma': ['Додома','Dodoma','Dodoma','دودوما','多多马'],
 'El Aaiún': ['Эль-Аюн','Laâyoune','El Aaiún','العيون','阿尤恩'],
 'Ottawa': ['Оттава','Ottawa','Ottawa','أوتاوا','渥太华'],
 'Washington D.C.': ['Вашингтон','Washington','Washington D. C.','واشنطن العاصمة','华盛顿'],
 'Astana': ['Астана','Astana','Astaná','أستانا','阿斯塔纳'],
 "N'Djamena": ['Нджамена',"N’Djaména",'Yamena','انجامينا','恩贾梅纳'],
 'Nuuk': ['Нуук','Nuuk','Nuuk','نوك','努克'],
 'Port-aux-Français': ['Порт-о-Франсе','Port-aux-Français','Port-aux-Français','بورت أو فرانسيس','法兰西港'],
 'Pretoria': ['Претория','Pretoria','Pretoria','بريتوريا','比勒陀利亚'],
 'Brasília': ['Бразилиа','Brasília','Brasilia','برازيليا','巴西利亚'],
 'Sucre': ['Сукре','Sucre','Sucre','سوكري','苏克雷'],
 'Bogotá': ['Богота','Bogotá','Bogotá','بوغوتا','波哥大'],
 'Panama City': ['Панама','Panama','Ciudad de Panamá','مدينة بنما','巴拿马城'],
 'San José': ['Сан-Хосе','San José','San José','سان خوسيه','圣何塞'],
 'San Salvador': ['Сан-Сальвадор','San Salvador','San Salvador','سان سلفادور','圣萨尔瓦多'],
 'Guatemala City': ['Гватемала','Guatemala','Ciudad de Guatemala','مدينة غواتيمالا','危地马拉城'],
 'Belmopan': ['Бельмопан','Belmopan','Belmopán','بلموبان','贝尔莫潘'],
 'Georgetown': ['Джорджтаун','Georgetown','Georgetown','جورج تاون','乔治敦'],
 'Quito': ['Кито','Quito','Quito','كيتو','基多'],
 'Kingston': ['Кингстон','Kingston','Kingston','كينغستون','金斯敦'],
 'Abuja': ['Абуджа','Abuja','Abuya','أبوجا','阿布贾'],
 'Yaoundé': ['Яунде','Yaoundé','Yaundé','ياوندي','雅温得'],
 'Lomé': ['Ломе','Lomé','Lomé','لومي','洛美'],
 'Yamoussoukro': ['Ямусукро','Yamoussoukro','Yamusukro','ياموسوكرو','亚穆苏克罗'],
 'Lilongwe': ['Лилонгве','Lilongwe','Lilongüe','ليلونغوي','利隆圭'],
 'Lobamba': ['Лобамба','Lobamba','Lobamba','لوبامبا','洛班巴'],
 'Abu Dhabi': ['Абу-Даби','Abou Dabi','Abu Dabi','أبوظبي','阿布扎比'],
 'Doha': ['Доха','Doha','Doha','الدوحة','多哈'],
 'Kuwait City': ['Эль-Кувейт','Koweït','Ciudad de Kuwait','مدينة الكويت','科威特城'],
 'Port Vila': ['Порт-Вила','Port-Vila','Port Vila','بورت فيلا','维拉港'],
 'Naypyidaw': ['Нейпьидо','Naypyidaw','Naipyidó','نايبيداو','内比都'],
 'Hanoi': ['Ханой','Hanoï','Hanói','هانوي','河内'],
 'Ulan Bator': ['Улан-Батор','Oulan-Bator','Ulán Bator','أولان باتور','乌兰巴托'],
 'New Delhi': ['Нью-Дели','New Delhi','Nueva Delhi','نيودلهي','新德里'],
 'Kathmandu': ['Катманду','Katmandou','Katmandú','كاتماندو','加德满都'],
 'Islamabad': ['Исламабад','Islamabad','Islamabad','إسلام آباد','伊斯兰堡'],
 'Chișinău': ['Кишинёв','Chișinău','Chisináu','كيشيناو','基希讷乌'],
 'Ankara': ['Анкара','Ankara','Ankara','أنقرة','安卡拉'],
 'Tirana': ['Тирана','Tirana','Tirana','تيرانا','地拉那'],
 'Bern': ['Берн','Berne','Berna','برن','伯尔尼'],
 'Nouméa': ['Нумеа','Nouméa','Numea','نوميا','努美阿'],
 'Honiara': ['Хониара','Honiara','Honiara','هونيارا','霍尼亚拉'],
 'Wellington': ['Веллингтон','Wellington','Wellington','ويلينغتون','惠灵顿'],
 'Canberra': ['Канберра','Canberra','Canberra','كانبرا','堪培拉'],
 'Beijing': ['Пекин','Pékin','Pekín','بكين','北京'],
 'Bandar Seri Begawan': ['Бандар-Сери-Бегаван','Bandar Seri Begawan','Bandar Seri Begawan','بندر سري بكاوان','斯里巴加湾市'],
 'Asmara': ['Асмэра','Asmara','Asmara','أسمرة','阿斯马拉'],
 'Asunción': ['Асунсьон','Asuncion','Asunción','أسونسيون','亚松森'],
 "Sana'a": ['Сана','Sanaa','Saná','صنعاء','萨那'],
 'North Nicosia': ['Северная Никосия','Nicosie-Nord','Nicosia del Norte','شمال نيقوسيا','北尼科西亚'],
 'Rabat': ['Рабат','Rabat','Rabat','الرباط','拉巴特'],
 'Hargeisa': ['Харгейса','Hargeisa','Hargeisa','هرجيسا','哈尔格萨'],
 'Pristina': ['Приштина','Pristina','Pristina','بريشتينا','普里什蒂纳'],
 # CLDR entries are sometimes omitted even when common city localization differs from English:
 'London': ['Лондон','Londres','Londres','لندن','伦敦'],
 'Tokyo': ['Токио','Tokyo','Tokio','طوكيو','东京'],
 'Rome': ['Рим','Rome','Roma','روما','罗马'],
 'Paris': ['Париж','Paris','París','باريس','巴黎'],
 'Moscow': ['Москва','Moscou','Moscú','موسكو','莫斯科'],
 'Berlin': ['Берлин','Berlin','Berlín','برلين','柏林'],
 'Seoul': ['Сеул','Séoul','Seúl','سيول','首尔'],
 'Cairo': ['Каир','Le Caire','El Cairo','القاهرة','开罗'],
 'Vienna': ['Вена','Vienne','Viena','فيينا','维也纳'],
 'Kyiv': ['Киев','Kyiv','Kiev','كييف','基辅'],
 'Kiev': ['Киев','Kyiv','Kiev','كييف','基辅'],
 'Jerusalem': ['Иерусалим','Jérusalem','Jerusalén','القدس','耶路撒冷'],
}
langs=['ru','fr','es','ar','zh']
cldr={}
for lang in langs:
 tz=Locale.parse(lang).time_zones
 cldr[lang]={key.split('/')[-1].replace('_',' ').lower():info.get('city') for key,info in tz.items() if info.get('city')}
# Additional synonym mapping for known variants of city time zone identifiers.
alias={'Ashgabat':'Ashkhabad','Kiev':'Kyiv','Mumbai':'Calcutta','Port-au-Prince':'Port-au-Prince'}
rows={}
for c in items:
 city=c.get('capital')
 if not city:continue
 vals={'en':city}
 for i,lang in enumerate(langs):
  value=(manual.get(city) or [None]*len(langs))[i]
  if not value:
   value=cldr[lang].get(city.lower()) or cldr[lang].get(alias.get(city,'').lower())
  # City names that are the same across languages are valid names; source capital
  # remains the explicitly visible fallback, not an alleged verified translation.
  if value: vals[lang]=value
 rows[c['code']]=vals
p=ROOT/'data/capitals.js'
p.write_text('/* Capital exonyms from Unicode CLDR (via Babel) and conventional-name overrides. */\nwindow.ATLAS_CAPITALS='+json.dumps(rows,ensure_ascii=False,separators=(',',':'))+';\n',encoding='utf-8')
for lang in langs:
 print(lang,sum(lang in row for row in rows.values()),'of',len(rows))
print('wrote',p)

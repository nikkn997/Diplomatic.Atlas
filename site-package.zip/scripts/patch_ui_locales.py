from pathlib import Path
p=Path(__file__).resolve().parent.parent/'src/live.js'
s=p.read_text(encoding='utf-8')
# Keep translations in runtime, author UI strings in all supported languages.
needle='const esc=s=>String(s??\'\').replace('
assert needle in s
block='''const extendedLocales={
 fr:{title:'Actualité mondiale',lead:'Actualités sourcées, archives et mises à jour planifiées dans une même rédaction.',badge:'FLUX DES ÉDITEURS · INSTANTANÉ PROGRAMMÉ',all:'Toutes les sources',search:'Rechercher un titre, un lieu ou une source',updated:'Dernière récupération réussie',notReady:'Aucune mise à jour programmée publiée. Les archives restent accessibles.',stale:'Données de plus de 72 heures : consultez l’éditeur.',empty:'Aucun résultat',view:'Lire chez l’éditeur',status:'Traductions non officielles. Les titres ne prouvent pas de liens diplomatiques.',refresh:'Rechercher une mise à jour',more:'Événements vérifiés sur la carte',local:'Mode hors ligne : archives enregistrées. Les mises à jour démarrent après publication.',now:'État des mises à jour',date:'Publié',publisher:'Éditeur',total:'titres',archiveReady:'Archives intégrées chargées',period:'Période',allTime:'Toutes les dates',day:'24 heures',week:'7 jours',month2:'60 jours',savedOnly:'Enregistrés',recent:'Plus récents',oldest:'Plus anciens',sourceDesk:'Rédaction liée aux sources',archive:'Événements historiques documentés',archiveNote:'Les événements vérifiés sont distincts des titres de presse.',viewArchive:'Voir l’événement',save:'Enregistrer',unsave:'Retirer des favoris',showMore:'Afficher plus',timeWarning:'La date de publication n’est pas toujours celle de l’événement.',sourceStatus:'État du flux',partial:'Certaines sources ne se sont pas mises à jour',full:'Sources mises à jour',next:'Après publication, des titres peuvent être mis à jour automatiquement environ toutes les six heures. Ce n’est pas un fil en direct.',summaryFallback:'Consultez la source pour le contexte complet.',location:'Lieu',category:'Rubrique',original:'Original en anglais',unofficial:'Traduction non officielle',sourceCard:'Visuel du site, pas une photo de l’événement',imageCredit:'Image fournie par la source'},
 es:{title:'Panorama mundial',lead:'Noticias con fuentes, archivo seleccionado y actualizaciones programadas.',badge:'FUENTES · CAPTURA PROGRAMADA',all:'Todas las fuentes',search:'Buscar noticias, lugares o fuentes',updated:'Última actualización correcta',notReady:'Todavía no hay una actualización automática publicada. El archivo sigue disponible.',stale:'Datos de más de 72 horas; consulta el medio.',empty:'No hay resultados',view:'Leer en el medio',status:'Traducciones no oficiales. Los titulares no implican vínculos diplomáticos.',refresh:'Comprobar actualizaciones',more:'Eventos documentados en el mapa',local:'Modo sin conexión: archivo guardado. Las actualizaciones empiezan tras publicar el sitio.',now:'Estado de actualización',date:'Publicado',publisher:'Fuente',total:'titulares',archiveReady:'Archivo integrado cargado',period:'Período',allTime:'Todas las fechas',day:'24 horas',week:'7 días',month2:'60 días',savedOnly:'Guardados',recent:'Más recientes',oldest:'Más antiguos',sourceDesk:'Noticias con fuentes',archive:'Eventos históricos documentados',archiveNote:'Archivo de eventos separado de los titulares.',viewArchive:'Ver evento',save:'Guardar',unsave:'Quitar de guardados',showMore:'Mostrar más',timeWarning:'La fecha de publicación no siempre coincide con la del evento.',sourceStatus:'Estado de las fuentes',partial:'No se actualizaron todas las fuentes',full:'Fuentes actualizadas',next:'Tras publicar el sitio, los titulares pueden actualizarse automáticamente cada seis horas aproximadamente. No es una transmisión en directo.',summaryFallback:'Consulta la fuente original para más información.',location:'Lugar',category:'Sección',original:'Original en inglés',unofficial:'Traducción no oficial',sourceCard:'Imagen decorativa, no fotografía del evento',imageCredit:'Imagen del editor'},
 ar:{title:'موجز العالم',lead:'أخبار موثقة بالمصادر وأرشيف مختار وتحديثات مجدولة.',badge:'تحديثات الناشرين · لقطة مجدولة',all:'جميع المصادر',search:'ابحث في الأخبار والأماكن والمصادر',updated:'آخر جلب ناجح',notReady:'لم يُنشر تحديث آلي بعد، والأرشيف متاح.',stale:'البيانات أقدم من 72 ساعة؛ تحقق من الناشر.',empty:'لا توجد نتائج',view:'اقرأ لدى الناشر',status:'الترجمات غير رسمية، والعناوين لا تثبت علاقات دبلوماسية.',refresh:'التحقق من تحديث جديد',more:'أحداث موثقة على الخريطة',local:'وضع دون اتصال: الأرشيف محفوظ، والتحديث الآلي يبدأ بعد النشر.',now:'حالة التحديث',date:'نُشر في',publisher:'الناشر',total:'عنواناً',archiveReady:'تم تحميل الأرشيف',period:'الفترة',allTime:'كل التواريخ',day:'24 ساعة',week:'7 أيام',month2:'60 يوماً',savedOnly:'المحفوظ فقط',recent:'الأحدث أولاً',oldest:'الأقدم أولاً',sourceDesk:'غرفة أخبار موثقة بالمصادر',archive:'أحداث تاريخية موثقة',archiveNote:'الأحداث الموثقة منفصلة عن عناوين الصحف.',viewArchive:'عرض الحدث',save:'حفظ',unsave:'إزالة من المحفوظ',showMore:'عرض المزيد',timeWarning:'تاريخ النشر ليس بالضرورة تاريخ الحدث.',sourceStatus:'حالة الأخبار',partial:'تعذر تحديث بعض المصادر',full:'تم تحديث المصادر',next:'بعد النشر، يمكن تحديث العناوين تلقائياً كل ست ساعات تقريباً. هذه ليست تغطية مباشرة.',summaryFallback:'افتح المصدر للاطلاع على التفاصيل.',location:'الموقع',category:'القسم',original:'النص الأصلي بالإنجليزية',unofficial:'ترجمة غير رسمية',sourceCard:'صورة توضيحية، ليست صورة الحدث',imageCredit:'صورة من الناشر'},
 zh:{title:'全球简报',lead:'汇集有来源的新闻标题、精选档案和定时更新。',badge:'新闻来源 · 定时快照',all:'全部来源',search:'搜索标题、地点或来源',updated:'上次成功获取',notReady:'尚未发布自动更新，仍可查看已有档案。',stale:'数据已超过72小时，请查看原始媒体。',empty:'没有匹配结果',view:'前往原始报道',status:'译文非官方译本；标题不代表已证实的外交联系。',refresh:'检查更新',more:'查看地图上的来源事件',local:'离线模式：保留已有档案，发布后可自动更新。',now:'更新状态',date:'发布日期',publisher:'来源',total:'条标题',archiveReady:'已加载内置档案',period:'时间范围',allTime:'全部日期',day:'24小时',week:'7天',month2:'60天',savedOnly:'仅收藏',recent:'最新优先',oldest:'最早优先',sourceDesk:'有来源的新闻中心',archive:'有文献记录的历史事件',archiveNote:'核实事件档案与媒体标题分开显示。',viewArchive:'查看事件',save:'收藏',unsave:'取消收藏',showMore:'加载更多',timeWarning:'发布日期不一定是事件发生日期。',sourceStatus:'新闻源状态',partial:'部分来源未更新',full:'来源已更新',next:'网站发布后，标题大约每六小时可自动更新一次。这不是实时新闻流。',summaryFallback:'请查看原始报道了解更多。',location:'地点',category:'栏目',original:'英文原文',unofficial:'非官方翻译',sourceCard:'装饰性封面，非现场照片',imageCredit:'来源提供的图片'}
};
Object.assign(locales,extendedLocales);
Object.assign(locales.en,{original:'Original English',unofficial:'Unofficial translation',sourceCard:'Source card · not an event photograph',imageCredit:'Publisher-supplied image'});
Object.assign(locales.ru,{original:'Оригинал на английском',unofficial:'Неофициальный перевод',sourceCard:'Иллюстрация раздела, не фото события',imageCredit:'Изображение от источника'});
const deskLabels={
 en:{climate:'Climate',health:'Health',economy:'Economy',news:'News',multilateral:'Multilateral',reference:'Reference'},
 ru:{climate:'Климат',health:'Здравоохранение',economy:'Экономика',news:'Новости',multilateral:'Многосторонние отношения',reference:'Справка'},
 fr:{climate:'Climat',health:'Santé',economy:'Économie',news:'Actualités',multilateral:'Multilatéral',reference:'Référence'},
 es:{climate:'Clima',health:'Salud',economy:'Economía',news:'Noticias',multilateral:'Multilateral',reference:'Referencia'},
 ar:{climate:'المناخ',health:'الصحة',economy:'الاقتصاد',news:'أخبار',multilateral:'متعدد الأطراف',reference:'مرجع'},
 zh:{climate:'气候',health:'卫生',economy:'经济',news:'新闻',multilateral:'多边事务',reference:'参考'}
};
const translated=(item,lang)=>{
 if(lang==='en')return {title:item.title,summary:item.summary,translated:true};
 const corpus=window.ATLAS_NEWS_TRANSLATIONS?.[item.url]?.[lang];
 const value=item.translations?.[lang]||corpus;
 return {title:value?.title||item.title,summary:value?.summary||item.summary,translated:!!(value?.title&&value?.summary)};
};
'''
s=s.replace(needle,block+needle)
# Merge translations from live and archive by URL and keep best live media if present
old='''function mergedItems(){
 const map=new Map();
 for(const item of [...normalize(snapshot.items,'live'),...normalize(archive.items,'archive')]){if(!map.has(item.url))map.set(item.url,item)}
 return [...map.values()];
}'''
new='''function mergedItems(){
 const map=new Map();
 for(const item of [...normalize(archive.items,'archive'),...normalize(snapshot.items,'live')]){
  const prev=map.get(item.url);
  map.set(item.url,prev?{...prev,...item,image:item.image||prev.image,summary:item.summary||prev.summary,translations:{...(prev.translations||{}),...(item.translations||{})}}:item);
 }
 return [...map.values()];
}'''
assert old in s;s=s.replace(old,new)
s=s.replace("  flagCode:item.flagCode||'',\n", "  flagCode:item.flagCode||'',\n  translations:item.translations||{},\n")
s=s.replace("  locationLabel:item.locationLabel||'',\n  locationLabel:item.locationLabel||'',", "  locationLabel:item.locationLabel||'',")
# replace render for story card: make state language explicit and use labels
s=s.replace('function storyCard(item,l,lead=false){','function storyCard(item,l,lang,lead=false){')
s=s.replace(' const summary=item.summary||l.summaryFallback;\n const flagCode=resolveFlagCode(item);', ''' const copy=translated(item,lang);
 const summary=copy.summary||l.summaryFallback;
 const categoryText=(deskLabels[lang]||deskLabels.en)[item.category]||item.category||'news';
 const badge=lang==='en'?'':`<span class="news-translation-badge">${esc(l[copy.translated?'unofficial':'original'])}</span>`;
 const flagCode=resolveFlagCode(item);''')
s=s.replace(" · editorial image</span>", " · ${esc(l.imageCredit)}</span>")
s=s.replace(" · source card</span>", " · ${esc(l.sourceCard)}</span>")
s=s.replace('   <h3 lang="en"><a href="${esc(item.url)}" rel="noopener noreferrer" target="_blank">${esc(item.title)}</a></h3>', '   ${badge}<h3 lang="${copy.translated?esc(lang):\'en\'}"><a href="${esc(item.url)}" rel="noopener noreferrer" target="_blank">${esc(copy.title)}</a></h3>')
s=s.replace("${esc(item.category||'news')}", "${esc(categoryText)}")
s=s.replace("storyCard(first,l,true)", "storyCard(first,l,state.lang,true)")
s=s.replace("storyCard(item,l,false)", "storyCard(item,l,state.lang,false)")
s=s.replace("${esc(item.title)} ${item.publisher} ${item.locationLabel||''} ${item.summary||''}", "${esc(item.title)} ${item.publisher} ${item.locationLabel||''} ${item.summary||''} ${Object.values(window.ATLAS_NEWS_TRANSLATIONS?.[item.url]||{}).map(x=>x.title+' '+x.summary).join(' ')}")
# make UI labels translated bottom, and news archive title fallback avoid hidden English
s=s.replace('SOURCE-FIRST / NEWS DESK', '${esc(l.sourceDesk.toUpperCase())}')
s=s.replace('WORLD</strong><small>BRIEFING · SOURCE LINKED', 'WORLD</strong><small>BRIEFING · SOURCE LINKED')
s=s.replace('SOURCE ARCHIVE / REFERENCE', '${esc(l.archiveNote.toUpperCase())}')
# Label summary fallback after source-card etc: no need
p.write_text(s,encoding='utf-8')
print('patched',p)

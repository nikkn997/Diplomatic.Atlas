#!/usr/bin/env python3
"""Download known CC-licensed contextual photographs for the published site.

No photo here is represented as a photograph of a current article's event.
These four licensed works have source and license attribution in PHOTO_CREDITS.md.
This runs in the GitHub Actions build, not in visitors' browsers.
"""
from __future__ import annotations
import io
import sys
import urllib.request
from pathlib import Path
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parent.parent
DEST = ROOT / 'assets' / 'newsroom'
PHOTOS = {
    'who': 'https://upload.wikimedia.org/wikipedia/commons/2/2a/WHO_headquarters.jpg',
    'worldbank': 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/fe/World_Bank_Group_headquarters.jpg/960px-World_Bank_Group_headquarters.jpg',
    'imf': 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/34/11_International_Monetary_Fund_IMF_in_Washington_DC_USA_-_Creative_Commons_CC-BY.jpg/1280px-11_International_Monetary_Fund_IMF_in_Washington_DC_USA_-_Creative_Commons_CC-BY.jpg',
    'ungeneva': 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/64/UN_Geneva_Assembly_Hall.jpg/1280px-UN_Geneva_Assembly_Hall.jpg',
}
MAX_BYTES = 6_000_000


def retrieve(name: str, url: str, directory: Path = DEST) -> bool:
    if name not in PHOTOS or url != PHOTOS[name]:
        raise ValueError('Only audited Wikimedia Commons pictures are permitted')
    parsed = urlsplit(url)
    if parsed.scheme != 'https' or parsed.hostname != 'upload.wikimedia.org':
        raise ValueError('Unexpected photo host')
    target = directory / f'{name}.jpg'
    if target.exists() and 1_000 < target.stat().st_size <= MAX_BYTES:
        return True
    request = urllib.request.Request(url, headers={
        'User-Agent': 'DiplomaticAtlas/1.10 (independent educational project; Wikimedia CC attribution in PHOTO_CREDITS.md)',
        'Accept': 'image/jpeg',
    })
    try:
        with urllib.request.urlopen(request, timeout=16) as response:
            if urlsplit(response.url).hostname != 'upload.wikimedia.org':
                raise ValueError('Image redirect to an untrusted domain')
            content = response.read(MAX_BYTES + 1)
            if not response.headers.get('Content-Type', '').lower().startswith('image/jpeg'):
                raise ValueError('Unexpected image content type')
        if len(content) <= 1_000 or len(content) > MAX_BYTES or not content.startswith(b'\xff\xd8\xff'):
            raise ValueError('Invalid or excessive JPEG')
        directory.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content)
        print(f'Cached licensed contextual image: {name}, {len(content)} bytes')
        return True
    except (OSError, ValueError, TimeoutError) as exc:
        print(f'Image {name} unavailable: {exc}', file=sys.stderr)
        return False


def main():
    successful = sum(retrieve(name, url) for name, url in PHOTOS.items())
    print(f'Context images cached: {successful}/{len(PHOTOS)}')
    return 0  # Source outages must not prevent site publishing.


if __name__ == '__main__':
    raise SystemExit(main())

## v1.11 — source-verified, distinct forum photography
- Replaced repeated institutional reference portraits with seven individually assigned CC BY 4.0 photographs from Wikimedia Commons and EU audiovisual coverage of the IMF/WB 2026 Bangkok meetings and COP31.
- Added a strict MediaWiki API metadata/license verification and bounded JPEG download for GitHub Pages builds.
- The photo caption explicitly says it depicts a **related forum**, not the exact news story; full creator and license links are provided.
- On missing or unavailable media, the page renders a compact editorial card without pretending that a generic image depicts the reported event.
- Source-image URLs from RSS/Open Graph retain priority when supplied; no duplicate photo is repeated within a visible news collection.

## v1.10 — Source photography and licensed archive fallback

- News photos are now prioritized over decorative thumbnails when a publisher supplies RSS Media or Open Graph images.
- Headlines in the curated archive, including IMF, World Bank and UNEP items, are eligible for online Open Graph image enrichment.
- When no article photograph can be accessed, cards use actual **historical contextual photographs** of institutions, explicitly labeled "not this event" and credited to Wikimedia Commons contributors.
- GitHub Actions now caches four audited CC-licensed context photographs inside the published site; browsers can fall back to the original Commons image URL if downloading fails.
- Fixed the fallback chain so failures do not leave a blank block. Added photo pipeline tests and a file `PHOTO_CREDITS.md`.
- **Publisher photos are not guaranteed.** Publishers may omit media or restrict embedding. Context images must not be presented as event imagery.

## v1.9 — More publishers and persistent online map updates

- Added optional WTO, IAEA and EU Council RSS readers (now 8 publisher feeds).
- Extended the official venue-pin adapter for new institutional sources while preserving the no-inferred-connections rule.
- Set up a 5-minute GitHub Pages publication workflow that preserves prior data snapshots, handles failures and skips redundant deployments.
- Kept automatic translation best-effort and separated from original source headlines.

## v1.8 — complete seeded headline localization; bilingual city reference

- Added six-language headline and summary rendering with 18 curated source-linked records.
- Added 175 populated capital names with Russian, Arabic and Chinese exonyms; French and Spanish conventional variants and accurate name-preserving fallbacks.
- Corrected missing London capital in the static country source.
- Added optional free Argos Translate model workflow for future scheduled news, with explicit fallback to the English original when unavailable.
- Expanded automated news media parsing to WHO and more RSS media metadata, subject to publisher availability and licensing.
- Verified browser language switching on Russian/French/Chinese routes and added unit tests.

# Changelog

## v1.6 — cloth-backed comparison, sourced news photography, conservative event updates

- Fixed the invisible country comparison flags by replacing contradictory CSS background layering with one visible local textile pseudo-layer.
- Built 177 cloth-style country flag backgrounds and 177 flat image assets (offline capable) using `scripts/build_flag_fabric.py` from the bundled Noto Emoji flag artwork.
- Reworked World Briefing to use actual publisher-provided RSS/page metadata photos when available; no event photography is fabricated from flag images. When no verified image exists, use a text-only magazine card.
- Expanded the scheduled RSS fetch to UN News, BBC World, UN Geneva press items and UN Geneva meeting summaries. Added image host and HTTPS checks, simple attribution and bounded open-graph image fallback.
- Added `scripts/update_events.py`, a cautious parser for meetings and negotiations with places named in official headlines, publishing additional venue-only points for 2D/3D. No automatic participant connections or assumed outcomes.
- Bundled four more sourced recent events and a fresh November 2026 starter headline archive.
- Added Pages workflow integration and a ten-minute client refresh check for published news and events while the tab is visible.
- Updated local tests and deployment guidance for v1.6. Initial live remote feeds require a first successful GitHub Actions run.

## v1.5
- Reworked comparison cards so the flag fills the card background in a cleaner editorial style.
- Replaced fragile newsroom emoji badges with sharper flag image badges.
- News cards now use large location-based visuals instead of empty grey placeholders when no publisher art is bundled.
- Prepared the same deployment/update plumbing for scheduled refresh after publishing.

## v1.4
- Reworked country comparison so each country card uses the flag as the visual background layer with the data text on top.
- Improved newsroom cards: preserved seeded images/summaries, added sharper flat emoji flag badges, and seeded a visible newsroom snapshot.
- Added Apple/macOS-friendly system font stack and extra responsive polish.
- Kept the GitHub Pages automation workflow for scheduled headline and WDI refreshes after deployment.

# Changelog


## v1.3 — Live newsroom seed, richer signals, stronger compare visuals
- Added a bundled **news archive** with sourced headlines and summaries so the World Briefing module is useful immediately, even before the first scheduled refresh runs.
- Expanded the newsroom UI with image-led cards, richer metadata, 60-day filtering, dynamic publisher tabs and better fallbacks for offline/local use.
- Strengthened the country comparison hero with a dedicated large flag art layer and improved overlay readability.
- Expanded Diplomatic Signals with additional recent health, multilateral and economic governance cases for the 2D map and 3D globe.
- Prepared the static site for GitHub Pages refreshes with the new `data/newsArchive.js` asset cached offline.

## 1.2.0 — Flag-led comparison, source-dated WDI observations, expanded UN vote archive, Mac/PWA support

- Flag-filled, shadowed immersive compare cards and selected metric overlays (with date/source context).
- Added dated 2025 World Bank WDI population and GDP seed figures for France and Germany, with direct series citations and no invented GDP for other countries.
- World Bank refresh-on-demand in Country Compare and scheduled World Bank data retrieval via GitHub Actions, preserving old data on network failure.
- Expanded curated General Assembly archive to **24** official vote totals, with 2025 resolutions, year/topic/search filters, CSV export and non-voting/participation context. Original titles retained alongside editorial labels.
- Added command palette: ⌘K on macOS, Ctrl+K on Windows/Linux, keyboard/escape control.
- Added PWA manifest, static service worker and iOS touch icon. News/indicator resources use network-first strategies.
- Updated six-language interface strings, responsive styles and reduced-motion accommodation.
- **Not verified:** external RSS and World Bank fetching from GitHub-runner network, Safari/WebKit devices, publication to an actual GitHub account.


## v1.1.0 — Research Desk / newsroom and publication candidate

- Added a new interactive homepage **Research Desk** with accessible source-linked navigation and archived event visibility, plus clickable orbit links in the main hero.
- Expanded Country Compare with a **responsive interactive metric chart** for population, GDP, GDP per capita, area, and approximate density; country swap, source/year notes and CSV export.
- Separated historical, undated countryinfo-derived fallback figures from dated World Bank WDI observations. The initial WDI snapshot is empty until a successful refresh; GDP is never fabricated.
- Added a robust stdlib-only **World Bank WDI refresh** (`scripts/update_indicators.py`) for latest available population and GDP observations, preserving the last successfully retrieved snapshot during outages and recording the observation year.
- Rebuilt World Briefing into an editorial newsroom with lead story, publisher filters, date filters, sort order, search, local bookmarks, dated source links and a separate verified historical event section.
- Improved chapter navigation scroll reset, responsive layouts and reduced-motion styles.
- Extended GitHub Actions workflow to update both attributed publisher headlines and WDI data and deploy the static site (on `main`, normally every 6 hours, subject to platform limits).
- Added `DEPLOY_GITHUB_PAGES_RU.md`, an onboarding guide for publishing through GitHub Desktop.
- Tested: JavaScript syntax, Node data tests, Python RSS/WDI fixtures, browser smoke checks including interactive swap, filters, saves and 390px mobile layouts. Production RSS/API network access and GitHub Pages deployment have **not** been tested in a real account.

## v1.0.0

See the prior release for premium comparison cards and local flag artwork for mapped territories.

# Sources and methodology — Diplomatic Atlas v1.2

**Snapshot date:** 23 November 2026. Dated events and aggregate votes were selected for educational comparison. Geographical data and countries are historic offline metadata, not reverified per-country facts.

## Events (original institutional primary sources)

The venue date, city, summary and named participants in the UI come from the linked institutional records. A **line** from a venue to a capital is an illustrative participant locator, not a measured flight route, diplomatic alliance, or claim of who met where in the city. Coordinates are approximate. Only named participants are connected; blank lines intentionally mean no curated participant set.

| Date | Event | Venue | Documented participant codes | Original source |
|---|---|---|---|---|
| 2026-11-10 | US–Russia–Ukraine talks in Abu Dhabi | Abu Dhabi | USA, RUS, UKR | https://www.mofa.gov.ae/en/MediaHub/News/2026/11/10/10-11-2026-UAE-Russia-Ukraine-USA |
| 2022-07-22 | Black Sea Grain Initiative | Istanbul | UKR, RUS, TUR | https://www.un.org/en/black-sea-grain-initiative/faq |
| 2015-07-14 | Iran nuclear agreement (JCPOA) | Vienna | IRN, CHN, FRA, DEU, RUS, GBR, USA | https://main.un.org/securitycouncil/en/content/2231/background |
| 2015-12-12 | Adoption of the Paris Agreement | Paris | none encoded | https://unfccc.int/process-and-meetings/the-paris-agreement |
| 2023-12-13 | COP28 outcomes in Dubai | Dubai | none encoded | https://unfccc.int/cop28/outcomes |
| 2024-09-22 | UN Pact for the Future adopted | New York | none encoded | https://www.un.org/sustainabledevelopment/blog/2024/09/press-release-sotf-2024/ |
| 2022-12-19 | Kunming–Montréal biodiversity framework | Montréal | CHN, CAN | https://www.cbd.int/article/cop15-cbd-press-release-final-19dec2022 |
| 2024-03-01 | UN Environment Assembly (UNEA-6) | Nairobi | none encoded | https://www.unep.org/en/news-and-stories/press-release/un-environment-assembly-advances-collaborative-action-triple |
| 2023-12-12 | UNGA resolution ES-10/22 | New York | none encoded | https://digitallibrary.un.org/record/4031196 |

## UN General Assembly recorded aggregate totals

These figures are recorded **in favour / against / abstain**; they are not vote-by-country datasets. Non-voting/absent member states are omitted. The exact resolution symbol and original UN document are shown so a reader can verify the adoption record.

| Resolution | Date | In favour | Against | Abstentions | Original UN Digital Library record |
|---|---|---:|---:|---:|---|
| A/RES/ES-11/1 | 2022-03-02 | 141 | 5 | 35 | https://digitallibrary.un.org/record/3965290 |
| A/RES/ES-11/2 | 2022-03-24 | 140 | 5 | 38 | https://digitallibrary.un.org/record/3966630 |
| A/RES/ES-11/3 | 2022-04-07 | 93 | 24 | 58 | https://digitallibrary.un.org/record/3967950 |
| A/RES/ES-11/4 | 2022-10-12 | 143 | 5 | 35 | https://digitallibrary.un.org/record/3990673 |
| A/RES/ES-11/5 | 2022-11-14 | 94 | 14 | 73 | https://digitallibrary.un.org/record/3994481 |
| A/RES/ES-11/6 | 2023-02-23 | 141 | 7 | 32 | https://digitallibrary.un.org/record/4004933 |
| A/RES/ES-10/21 | 2023-10-27 | 120 | 14 | 45 | https://digitallibrary.un.org/record/4025940 |
| A/RES/ES-10/22 | 2023-12-12 | 153 | 10 | 23 | https://digitallibrary.un.org/record/4031196 |
| A/RES/ES-10/23 | 2024-05-10 | 143 | 9 | 25 | https://digitallibrary.un.org/record/4048289 |
| A/RES/ES-10/24 | 2024-09-18 | 124 | 14 | 43 | https://digitallibrary.un.org/record/4062853 |
| A/RES/ES-10/25 | 2024-12-11 | 159 | 9 | 11 | https://digitallibrary.un.org/record/4070092 |
| A/RES/ES-10/26 | 2024-12-11 | 158 | 9 | 13 | https://digitallibrary.un.org/record/4070093 |
| A/RES/ES-11/8 | 2025-02-24 | 93 | 8 | 73 | https://digitallibrary.un.org/record/4076919 |

### Important interpretive distinctions

- **ES-10/23 (10 May 2024):** the resolution concerns a membership application for the State of Palestine and recommends reconsideration; its adoption does **not itself** grant UN membership.

- **ES-10/21:** recorded tally is **120 for, 14 against, 45 abstentions**. Avoid confusing it with subsequent resolutions with different numbers.

- Official vote totals do not reveal all individual-country positions unless the underlying official roll-call is separately inspected. No bilateral alignment coefficients are computed in this release.

## Geographic, languages, flags, imagery

- Natural Earth public-domain data: https://www.naturalearthdata.com/about/terms-of-use/ . Map is low-resolution and not an authoritative statement of international borders.

- Countryinfo historical metadata (not current source of truth): https://pypi.org/project/countryinfo/ . All 177 features have a local geographic dossier; **not all are sovereign countries or UN member states**.

- Standard flag illustrations originate from Noto Color Emoji (SIL OFL): https://github.com/googlefonts/noto-emoji . Three feature codes use neutral local markers rather than an asserted national flag.

- World Bank Open Data direct reference: https://data.worldbank.org/ . Country pages are external; their accessibility cannot be guaranteed.

- UN Digital Library home: https://digitallibrary.un.org/ .

## Corrections workflow (for a future public release)

For any disputed claim: note the exact label, source document, vote date, original language, and timestamp; correct the versioned underlying data row; add the correction to CHANGELOG; never silently alter a historical snapshot. Country metadata should be replaced by an independently verified, dated country-data ingestion pipeline before publication as a trusted reference.

## v0.9 additions (new data checked against official sources)

The following four historical cases have been added. The supplied date is the **documented event date**, which can differ from the publication date of the linked institutional news article. Pins are approximate event locations, not a GPS record of delegation members.

| Date | Event | Venue | Participant lines | Original source |
|---|---|---|---|---|
| 2015-09-25 | Adoption of the 2030 Agenda for Sustainable Development | New York, USA | none | https://www.un.org/en/conferences/environment/newyork2015 |
| 2023-06-19 | Adoption of the BBNJ high-seas biodiversity agreement | New York, USA | none | https://www.un.org/bbnjagreement/en/bbnj-agreement/history |
| 2024-11-24 | COP29 climate-finance decision, Baku | Baku, Azerbaijan | none | https://unfccc.int/news/cop29-un-climate-conference-agrees-to-triple-finance-to-developing-countries-protecting-lives-and |
| 2025-05-20 | World Health Assembly adopts WHO Pandemic Agreement | Geneva, Switzerland | none | https://www.who.int/news/item/20-05-2025-world-health-assembly-adopts-historic-pandemic-agreement-to-make-the-world-more-equitable-and-safer-from-future-pandemics |

**Specific warnings:**

- A treaty's adoption is distinct from entry into force. The BBNJ agreement was adopted in June 2023; the UN confirms that it entered into force on 17 January 2026 (https://www.un.org/bbnjagreement/en/bbnj-agreement/becoming-party). The 2023 pin documents **adoption**, not legal status on every subsequent date.
- The WHO Pandemic Agreement was adopted by the World Health Assembly on 20 May 2025. The historical pin does not prove that its obligations are already in force for a particular state.
- The site does not automatically infer participant countries for these globally attended events; no country-to-host arcs are shown without a specific documented role.
- ES-11/1 and ES-11/2 official UN resolutions use the word “Aggression” in their official titles (https://digitallibrary.un.org/record/3965290 and https://digitallibrary.un.org/record/3966630). The v0.9 UI adds a *separate descriptive headline* using the user's requested concise conflict framing, but preserves the original UN title, source URL, date and recorded tally on screen. Editorial labels never replace primary document titles.
- Each of the 13 General Assembly vote records now has a short **educational context note** (`context`). It is a thematic summary, not a quotation or new official title. The summary does not show country-by-country voting positions. For any academic citation use the direct UN Digital Library record rather than the paraphrase.

## News data ingestion and editorial policy

Configured publisher RSS streams:

- UN News: https://news.un.org/feed/subscribe/en/news/all/rss.xml
- BBC World: https://feeds.bbci.co.uk/news/world/rss.xml

The scheduled Python updater (`scripts/update_news.py`) is an RSS **headline retriever**, not an AI reporter, fact checker, location classifier or realtime source. It preserves the original title wording, publisher, article timestamp and direct publisher URL, to a maximum of 48 items retained from up to eight days of content. No story text, image, political opinion, geolocation or event-participant graph is generated.

Publisher outages are preserved as an explicit prior snapshot. Every public digest presents the **last successful retrieval timestamp** and warns after 72 hours. The initial ZIP ships with `updated_at:null` and an empty list because external feeds could not be reached from the build environment; its content must not be described as live. The automated update runs only after a repository owner enables and deploys the scheduled workflow. Scheduled builds are best-effort; consult GitHub documentation for delays and public-repository inactivity disabling.

BBC states that RSS feed use requires prominent BBC attribution and hyperlink; therefore each headline card links directly to the provider. Source: https://downloads.bbc.co.uk/usingthebbc/bbc_terms_of_use_19September2022english.pdf . Confirm license requirements before extending beyond linked headlines.

To add articles to the **Signals geographic map**, an editor must manually document: event date and physical location, source with original language, named participants and their role, certainty of each claim, correction/retraction status, and revision history. An RSS title alone is **not sufficient** to create a diplomatic connection between countries.


## v1.1 — Data provenance and comparisons

- **WDI snapshots**: `data/indicators.js` and `data/indicators.json`, filled by `scripts/update_indicators.py` on a successful remote GitHub Actions run. Indicators: `SP.POP.TOTL` (population total), `NY.GDP.MKTP.CD` (GDP, current US$) and `NY.GDP.PCAP.CD` (GDP per capita, current US$). Each datum carries the **observation year** returned by the API. Retrieval date is not confused with the observation year. URL: https://datahelpdesk.worldbank.org/knowledgebase/articles/898581-api-basic-call-structures.
- WDI may omit some countries or territories. The app displays **unavailable** rather than fabricating GDP observations. For population only, an old offline countryinfo reference is shown with an explicit **unverified source year** warning.
- Geographic area comes from the pre-existing historical countryinfo reference, not a current official territorial measurement. Approximate density divides the population estimate by historical area; the two can differ in provenance and territorial definitions. Do not use derived density in a formal research claim without checking definitions.
- The news desk now permits local client-side saving and period/source filtering. Saved URLs remain in the user's browser storage; there are no tracking accounts. Publisher headlines stay attributed and linked, not converted to verified diplomatic relationships without manual verification.
- All newly added comparison labels are translated into the six site interface languages, while original article titles remain as published.


## v1.2 additions — source-linked 2025 UNGA votes

The 24-record archive is **selected**, not exhaustive. Below are newer records included in this release. Counts are yes / no / abstain; the denominator shown in the UI is the count of *recorded* yes+no+abstention values, and “not voting” is the arithmetic residual to 193 UN Member States. The residual is **not** an inference of absence, motive or any state’s position. Official resolution titles remain visible in the app next to editorial summaries.

| Resolution | Adopted | For | Against | Abstain | Source |
|---|---|---:|---:|---:|---|
| A/RES/80/215 | 2025-12-18 | 174 | 3 | 4 | https://digitallibrary.un.org/record/4098443 |
| A/RES/80/207 | 2025-12-18 | 127 | 23 | 32 | https://digitallibrary.un.org/record/4098435 |
| A/RES/80/195 | 2025-12-15 | 164 | 8 | 9 | https://digitallibrary.un.org/record/4098155 |
| A/RES/80/190 | 2025-12-15 | 176 | 4 | 1 | https://digitallibrary.un.org/record/4098158 |
| A/RES/80/116 | 2025-12-12 | 139 | 12 | 19 | https://www.un.org/unispal/document/general-assembly-resolution-12dec25/ |
| A/RES/80/84 B | 2025-12-05 | 174 | 3 | 0 | https://digitallibrary.un.org/record/4096720 |
| A/RES/80/84 A | 2025-12-05 | 173 | 3 | 0 | https://digitallibrary.un.org/record/4095066 |
| A/RES/80/72 | 2025-12-02 | 151 | 11 | 11 | https://digitallibrary.un.org/record/4095625 |
| A/RES/80/59 | 2025-12-01 | 116 | 50 | 11 | https://digitallibrary.un.org/record/4095957 |
| A/RES/80/51 | 2025-12-01 | 129 | 41 | 9 | https://digitallibrary.un.org/record/4095624 |
| A/RES/ES-10/27 | 2025-06-12 | 149 | 12 | 19 | https://digitallibrary.un.org/record/4084009 |
| A/RES/ES-11/8 | 2025-02-24 | 93 | 8 | 73 | https://digitallibrary.un.org/record/4076919 |

### v1.2 WDI seed: verified 2025 observations

| Country | 2025 population | 2025 GDP (current US dollars) | Source population | Source GDP |
|---|---:|---:|---|---|
| France | 68,720,337 | 3,366,315,927,447.33 | https://fred.stlouisfed.org/series/POPTOTFRA647NWDB | https://fred.stlouisfed.org/series/MKTGDPFRA646NWDB |
| Germany | 83,491,249 | 5,050,922,925,047.05 | https://fred.stlouisfed.org/series/POPTOTDEA647NWDB | https://fred.stlouisfed.org/series/MKTGDPDEA646NWDB |

These FRED series identify World Bank WDI as the underlying source. The 2025 period refers to the observed year, **not** the year when the figures were inspected or revised. Last inspected: 2026-11-24. WDI periodically revises historical values; fresh data after deployment can supersede the release seed. Derived GDP per capita = same-year nominal GDP / same-year population; do not confuse this with PPP GDP per capita. For other countries, the repository intentionally does not invent a current number.

Official World Bank Indicators API: https://datahelpdesk.worldbank.org/knowledgebase/articles/889392-about-the-indicators-api ; https://data.worldbank.org/indicator/SP.POP.TOTL ; https://data.worldbank.org/indicator/NY.GDP.MKTP.CD . All map borders and flag illustrations retain the historical/illustrative qualifications stated above.

### RSS and publication safeguards

The project stores publisher headline text, source URL and timestamp only; it does not scrape full article bodies or automatically assert participant-country relationships. Until the repository owner enables GitHub Pages and successfully runs the workflow, fresh headline availability and scheduled six-hour retrieval are **unconfirmed**. Next successful fetch timestamps are displayed. Failed provider requests preserve the previous data. Source material must be checked before drawing a diplomatic connection.

### QA and device disclosure

JavaScript and Python tests and an inline-resource Chromium harness verify selected functionality. The browser harness does **not** establish that real RSS feeds, API calls, GitHub Pages, iOS Safari, macOS Safari, or user-device 3D acceleration will work. Complete device smoke tests and editorial review before public announcement.


## v1.6 — Automated publisher photography and geolocation constraints

Photos appear only if the publisher RSS/OG image field supplies an HTTPS image from an accepted publisher/CDN hostname. They are displayed remotely with credit; the website does not store or claim ownership of the original photographs. The presence of a photo does not prove the photo was taken at the event; consult the original caption. If no supported photo exists, the news card becomes text-only, not a fabricated illustration.

Source venues on the live 2D/3D maps are generated only when the meeting/summit/talks plus city name appear explicitly in an official UN/UN Geneva headline. Dates are publication dates, not necessarily event dates. Coordinates are approximate city centres and are labelled title-derived. No automatic participant links, votes, alliances or negotiation outcomes are inferred. An empty event feed is preferable to inventing geographic connections.

UN Geneva RSS sources: https://www.ungeneva.org/en/news-media/rss

Official data API: https://api.worldbank.org/v2/

Relevant original historical sources are retained with each `data/events.js` entry. Added current examples from:
- https://www.ungeneva.org/en/about/ungeneva-explained/should-machines-make-decisions
- https://www.ungeneva.org/en/news-media/biweekly-calendar
- https://www.who.int/news/item/17-11-2026-governments-make-over-230-new-pledges-to-prevent-violence-against-children
- https://www.un.org/en/cop31-ends-without-climate-pact-un-chief-warns-there-%E2%80%98no-ambiguity-science%E2%80%99

## v1.9 — faster source updates for news and mapped events

Current candidate feeds in `scripts/update_news.py`:

- UN News — https://news.un.org/feed/subscribe/en/news/all/rss.xml
- BBC World — https://feeds.bbci.co.uk/news/world/rss.xml
- UN Geneva press items — https://www.ungeneva.org/news-media/press-items-list/rss.xml
- UN Geneva meeting summaries — https://www.ungeneva.org/news-media/meeting-summaries-list/rss.xml
- World Health Organization — https://www.who.int/rss-feeds/news-english.xml
- World Trade Organization — https://www.wto.org/library/rss/latest_news_e.xml (listed by WTO at https://www.wto.org/english/res_e/webcas_e/rss_e.htm)
- International Atomic Energy Agency — https://www.iaea.org/feeds/topnews (listed in IAEA NUCLEUS documentation; actual response to be confirmed after publication)
- Council of the European Union — https://www.consilium.europa.eu/en/rss/pressreleases.ashx/ (linked on https://www.consilium.europa.eu/en/about-site/rss/; actual response to be confirmed after publication)

News and institutional headlines may not arrive instantly at the source, may be blocked by provider rate limits, or may lack a usable photograph. Sources retain direct original URLs, publication timestamps, and summaries; no assertion of independent verification is made from an RSS headline alone.

The `update_events.py` bridge only uses an official institutional publisher's headline if it explicitly says that a *meeting, summit, talks, conference or negotiation* took place **in/at a named city from a curated place dictionary**. Each map pin uses approximate city-centre coordinates, records the publisher URL and explicitly notes that the precise venue and participant list have not been verified. It never constructs diplomatic participant lines from a headline. A geographical news location is **not** evidence of an alliance, agreement or endorsement.

Deployment uses a GitHub Actions schedule of `*/5 * * * *` UTC for the public repository `nikkn997/Diplomatic.Atlas`, respecting GitHub's minimum period and possible skipped/delayed scheduled executions. GitHub Pages itself is static, not a WebSocket live stream. The workflow persists validated JSON/JS snapshots in the repository under `snapshot-cache/` between runs, preventing accidental loss of older stories, and skips redundant deploys when no records change. WDI polling is throttled to approximately six hours.

Publisher photo URLs remain attributed and are displayed only when metadata exists and direct loading is possible; a source listing an image does not automatically grant a republication licence. Real publishing connectivity and article-image display cannot be established by local offline test fixtures.
